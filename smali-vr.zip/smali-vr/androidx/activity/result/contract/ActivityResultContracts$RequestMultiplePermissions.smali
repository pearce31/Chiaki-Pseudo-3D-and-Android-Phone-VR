.class public final Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;
.super Landroidx/activity/result/contract/ActivityResultContract;
.source "ActivityResultContracts.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/activity/result/contract/ActivityResultContract<",
        "[",
        "Ljava/lang/String;",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Ljava/lang/Boolean;",
        ">;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,807:1\n12537#2,2:808\n8676#2,2:810\n9358#2,4:812\n11365#2:816\n11700#2,3:817\n*S KotlinDebug\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions\n*L\n183#1:808,2\n190#1:810,2\n190#1:812,4\n203#1:816\n203#1:817,3\n*E\n"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroidx/activity/result/contract/ActivityResultContract;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final createIntent(Landroidx/activity/ComponentActivity;Ljava/lang/Object;)Landroid/content/Intent;
    .registers 4

    .line 1
    check-cast p2, [Ljava/lang/String;

    .line 2
    .line 3
    const-string v0, "context"

    .line 4
    .line 5
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    const-string p1, "input"

    .line 9
    .line 10
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    new-instance p1, Landroid/content/Intent;

    .line 14
    .line 15
    const-string v0, "androidx.activity.result.contract.action.REQUEST_PERMISSIONS"

    .line 16
    .line 17
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const-string v0, "androidx.activity.result.contract.extra.PERMISSIONS"

    .line 21
    .line 22
    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const-string p2, "Intent(ACTION_REQUEST_PE\u2026EXTRA_PERMISSIONS, input)"

    .line 27
    .line 28
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/String;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    return-object p1
.end method

.method public final getSynchronousResult(Landroidx/activity/ComponentActivity;Ljava/lang/Object;)Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;
    .registers 16

    .line 1
    check-cast p2, [Ljava/lang/String;

    .line 2
    .line 3
    const-string v0, "context"

    .line 4
    .line 5
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "input"

    .line 9
    .line 10
    invoke-static {v0, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    array-length v0, p2

    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x1

    .line 16
    if-nez v0, :cond_13

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v0, 0x0

    .line 21
    :goto_14
    if-eqz v0, :cond_1f

    .line 22
    .line 23
    new-instance p1, Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;

    .line 24
    .line 25
    sget-object p2, Lkotlin/collections/EmptyMap;->INSTANCE:Lkotlin/collections/EmptyMap;

    .line 26
    .line 27
    invoke-direct {p1, p2}, Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;-><init>(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    goto/16 :goto_fd

    .line 31
    .line 32
    :cond_1f
    array-length v0, p2

    .line 33
    const/4 v3, 0x0

    .line 34
    :goto_21
    if-ge v3, v0, :cond_d7

    .line 35
    .line 36
    aget-object v4, p2, v3

    .line 37
    .line 38
    sget-object v5, Landroidx/core/content/ContextCompat;->sLock:Ljava/lang/Object;

    .line 39
    .line 40
    if-eqz v4, :cond_cf

    .line 41
    .line 42
    invoke-static {}, Landroidx/core/os/BuildCompat;->isAtLeastT()Z

    .line 43
    .line 44
    .line 45
    move-result v5

    .line 46
    if-nez v5, :cond_b6

    .line 47
    .line 48
    const-string v5, "android.permission.POST_NOTIFICATIONS"

    .line 49
    .line 50
    invoke-static {v5, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 51
    .line 52
    .line 53
    move-result v5

    .line 54
    if-eqz v5, :cond_b6

    .line 55
    .line 56
    new-instance v4, Landroidx/core/app/NotificationManagerCompat;

    .line 57
    .line 58
    invoke-direct {v4, p1}, Landroidx/core/app/NotificationManagerCompat;-><init>(Landroidx/activity/ComponentActivity;)V

    .line 59
    .line 60
    .line 61
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 62
    .line 63
    const/16 v6, 0x18

    .line 64
    .line 65
    if-lt v5, v6, :cond_49

    .line 66
    .line 67
    iget-object v4, v4, Landroidx/core/app/NotificationManagerCompat;->mNotificationManager:Landroid/app/NotificationManager;

    .line 68
    .line 69
    invoke-static {v4}, Landroidx/core/os/LocaleListPlatformWrapper$$ExternalSyntheticApiModelOutline2;->m(Landroid/app/NotificationManager;)Z

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    goto :goto_b0

    .line 74
    :cond_49
    const-string v4, "appops"

    .line 75
    .line 76
    invoke-virtual {p1, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    check-cast v4, Landroid/app/AppOpsManager;

    .line 81
    .line 82
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 87
    .line 88
    .line 89
    move-result-object v6

    .line 90
    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v6

    .line 94
    iget v5, v5, Landroid/content/pm/ApplicationInfo;->uid:I

    .line 95
    .line 96
    :try_start_5f
    const-class v7, Landroid/app/AppOpsManager;

    .line 97
    .line 98
    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v7

    .line 102
    invoke-static {v7}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 103
    .line 104
    .line 105
    move-result-object v7

    .line 106
    const-string v8, "checkOpNoThrow"

    .line 107
    .line 108
    const/4 v9, 0x3

    .line 109
    new-array v10, v9, [Ljava/lang/Class;

    .line 110
    .line 111
    sget-object v11, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 112
    .line 113
    aput-object v11, v10, v1

    .line 114
    .line 115
    aput-object v11, v10, v2

    .line 116
    .line 117
    const-class v11, Ljava/lang/String;

    .line 118
    .line 119
    const/4 v12, 0x2

    .line 120
    aput-object v11, v10, v12

    .line 121
    .line 122
    invoke-virtual {v7, v8, v10}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 123
    .line 124
    .line 125
    move-result-object v8

    .line 126
    const-string v10, "OP_POST_NOTIFICATION"

    .line 127
    .line 128
    invoke-virtual {v7, v10}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    const-class v10, Ljava/lang/Integer;

    .line 133
    .line 134
    invoke-virtual {v7, v10}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v7

    .line 138
    check-cast v7, Ljava/lang/Integer;

    .line 139
    .line 140
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 141
    .line 142
    .line 143
    move-result v7

    .line 144
    new-array v9, v9, [Ljava/lang/Object;

    .line 145
    .line 146
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    .line 148
    .line 149
    move-result-object v7

    .line 150
    aput-object v7, v9, v1

    .line 151
    .line 152
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    aput-object v5, v9, v2

    .line 157
    .line 158
    aput-object v6, v9, v12

    .line 159
    .line 160
    invoke-virtual {v8, v4, v9}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    check-cast v4, Ljava/lang/Integer;

    .line 165
    .line 166
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 167
    .line 168
    .line 169
    move-result v4
    :try_end_a9
    .catch Ljava/lang/ClassNotFoundException; {:try_start_5f .. :try_end_a9} :catch_ae
    .catch Ljava/lang/NoSuchMethodException; {:try_start_5f .. :try_end_a9} :catch_ae
    .catch Ljava/lang/NoSuchFieldException; {:try_start_5f .. :try_end_a9} :catch_ae
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_5f .. :try_end_a9} :catch_ae
    .catch Ljava/lang/IllegalAccessException; {:try_start_5f .. :try_end_a9} :catch_ae
    .catch Ljava/lang/RuntimeException; {:try_start_5f .. :try_end_a9} :catch_ae

    .line 170
    if-nez v4, :cond_ac

    .line 171
    .line 172
    goto :goto_af

    .line 173
    :cond_ac
    const/4 v4, 0x0

    .line 174
    goto :goto_b0

    .line 175
    :catch_ae
    nop

    .line 176
    :goto_af
    const/4 v4, 0x1

    .line 177
    :goto_b0
    if-eqz v4, :cond_b4

    .line 178
    .line 179
    const/4 v4, 0x0

    .line 180
    goto :goto_c2

    .line 181
    :cond_b4
    const/4 v4, -0x1

    .line 182
    goto :goto_c2

    .line 183
    :cond_b6
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 184
    .line 185
    .line 186
    move-result v5

    .line 187
    invoke-static {}, Landroid/os/Process;->myUid()I

    .line 188
    .line 189
    .line 190
    move-result v6

    .line 191
    invoke-virtual {p1, v4, v5, v6}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    .line 192
    .line 193
    .line 194
    move-result v4

    .line 195
    :goto_c2
    if-nez v4, :cond_c6

    .line 196
    .line 197
    const/4 v4, 0x1

    .line 198
    goto :goto_c7

    .line 199
    :cond_c6
    const/4 v4, 0x0

    .line 200
    :goto_c7
    if-nez v4, :cond_cb

    .line 201
    .line 202
    const/4 v2, 0x0

    .line 203
    goto :goto_d7

    .line 204
    :cond_cb
    add-int/lit8 v3, v3, 0x1

    .line 205
    .line 206
    goto/16 :goto_21

    .line 207
    .line 208
    :cond_cf
    new-instance p1, Ljava/lang/NullPointerException;

    .line 209
    .line 210
    const-string p2, "permission must be non-null"

    .line 211
    .line 212
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    throw p1

    .line 216
    :cond_d7
    :goto_d7
    if-eqz v2, :cond_fc

    .line 217
    .line 218
    array-length p1, p2

    .line 219
    invoke-static {p1}, Lkotlin/collections/MapsKt__MapsJVMKt;->mapCapacity(I)I

    .line 220
    .line 221
    .line 222
    move-result p1

    .line 223
    const/16 v0, 0x10

    .line 224
    .line 225
    if-ge p1, v0, :cond_e4

    .line 226
    .line 227
    const/16 p1, 0x10

    .line 228
    .line 229
    :cond_e4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 230
    .line 231
    invoke-direct {v0, p1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 232
    .line 233
    .line 234
    array-length p1, p2

    .line 235
    :goto_ea
    if-ge v1, p1, :cond_f6

    .line 236
    .line 237
    aget-object v2, p2, v1

    .line 238
    .line 239
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 240
    .line 241
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    add-int/lit8 v1, v1, 0x1

    .line 245
    .line 246
    goto :goto_ea

    .line 247
    :cond_f6
    new-instance p1, Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;

    .line 248
    .line 249
    invoke-direct {p1, v0}, Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;-><init>(Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    goto :goto_fd

    .line 253
    :cond_fc
    const/4 p1, 0x0

    .line 254
    :goto_fd
    return-object p1
.end method

.method public final parseResult(Landroid/content/Intent;I)Ljava/lang/Object;
    .registers 8

    .line 1
    sget-object v0, Lkotlin/collections/EmptyMap;->INSTANCE:Lkotlin/collections/EmptyMap;

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq p2, v1, :cond_7

    .line 5
    .line 6
    goto/16 :goto_84

    .line 7
    .line 8
    :cond_7
    if-nez p1, :cond_b

    .line 9
    .line 10
    goto/16 :goto_84

    .line 11
    .line 12
    :cond_b
    const-string p2, "androidx.activity.result.contract.extra.PERMISSIONS"

    .line 13
    .line 14
    invoke-virtual {p1, p2}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    const-string v1, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    .line 19
    .line 20
    invoke-virtual {p1, v1}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    if-eqz p1, :cond_84

    .line 25
    .line 26
    if-nez p2, :cond_1c

    .line 27
    .line 28
    goto :goto_84

    .line 29
    :cond_1c
    new-instance v0, Ljava/util/ArrayList;

    .line 30
    .line 31
    array-length v1, p1

    .line 32
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 33
    .line 34
    .line 35
    array-length v1, p1

    .line 36
    const/4 v2, 0x0

    .line 37
    const/4 v3, 0x0

    .line 38
    :goto_25
    if-ge v3, v1, :cond_38

    .line 39
    .line 40
    aget v4, p1, v3

    .line 41
    .line 42
    if-nez v4, :cond_2d

    .line 43
    .line 44
    const/4 v4, 0x1

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    const/4 v4, 0x0

    .line 47
    :goto_2e
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    add-int/lit8 v3, v3, 0x1

    .line 55
    .line 56
    goto :goto_25

    .line 57
    :cond_38
    new-instance p1, Ljava/util/ArrayList;

    .line 58
    .line 59
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 60
    .line 61
    .line 62
    array-length v1, p2

    .line 63
    :goto_3e
    if-ge v2, v1, :cond_4a

    .line 64
    .line 65
    aget-object v3, p2, v2

    .line 66
    .line 67
    if-eqz v3, :cond_47

    .line 68
    .line 69
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    :cond_47
    add-int/lit8 v2, v2, 0x1

    .line 73
    .line 74
    goto :goto_3e

    .line 75
    :cond_4a
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    new-instance v2, Ljava/util/ArrayList;

    .line 84
    .line 85
    invoke-static {p1}, Lkotlin/collections/CollectionsKt__IteratorsJVMKt;->collectionSizeOrDefault(Ljava/lang/Iterable;)I

    .line 86
    .line 87
    .line 88
    move-result p1

    .line 89
    invoke-static {v0}, Lkotlin/collections/CollectionsKt__IteratorsJVMKt;->collectionSizeOrDefault(Ljava/lang/Iterable;)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(I)V

    .line 98
    .line 99
    .line 100
    :goto_63
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    if-eqz p1, :cond_80

    .line 105
    .line 106
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_80

    .line 111
    .line 112
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    new-instance v3, Lkotlin/Pair;

    .line 121
    .line 122
    invoke-direct {v3, p1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    goto :goto_63

    .line 129
    :cond_80
    invoke-static {v2}, Lkotlin/collections/MapsKt___MapsJvmKt;->toMap(Ljava/util/ArrayList;)Ljava/util/Map;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    :cond_84
    :goto_84
    return-object v0
.end method
