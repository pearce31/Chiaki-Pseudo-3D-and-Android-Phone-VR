.class public final Landroidx/appcompat/R$color;
.super Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static onCreateInputConnection(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V
    .registers 3

    .line 1
    if-eqz p2, :cond_20

    .line 2
    .line 3
    iget-object p2, p1, Landroid/view/inputmethod/EditorInfo;->hintText:Ljava/lang/CharSequence;

    .line 4
    .line 5
    if-nez p2, :cond_20

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    :goto_a
    instance-of p2, p0, Landroid/view/View;

    .line 12
    .line 13
    if-eqz p2, :cond_20

    .line 14
    .line 15
    instance-of p2, p0, Landroidx/appcompat/widget/WithHint;

    .line 16
    .line 17
    if-eqz p2, :cond_1b

    .line 18
    .line 19
    check-cast p0, Landroidx/appcompat/widget/WithHint;

    .line 20
    .line 21
    invoke-interface {p0}, Landroidx/appcompat/widget/WithHint;->getHint()Ljava/lang/CharSequence;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    iput-object p0, p1, Landroid/view/inputmethod/EditorInfo;->hintText:Ljava/lang/CharSequence;

    .line 26
    .line 27
    goto :goto_20

    .line 28
    :cond_1b
    invoke-interface {p0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    goto :goto_a

    .line 33
    :cond_20
    :goto_20
    return-void
.end method
