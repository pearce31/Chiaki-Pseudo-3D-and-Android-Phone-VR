.class public final Landroidx/appcompat/app/AppCompatDelegateImpl$3;
.super Ljava/lang/Object;
.source "AppCompatDelegateImpl.java"

# interfaces
.implements Landroidx/core/view/OnApplyWindowInsetsListener;


# instance fields
.field public final synthetic this$0:Landroidx/appcompat/app/AppCompatDelegateImpl;


# direct methods
.method public constructor <init>(Landroidx/appcompat/app/AppCompatDelegateImpl;)V
    .registers 2

    .line 1
    iput-object p1, p0, Landroidx/appcompat/app/AppCompatDelegateImpl$3;->this$0:Landroidx/appcompat/app/AppCompatDelegateImpl;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroidx/core/view/WindowInsetsCompat;)Landroidx/core/view/WindowInsetsCompat;
    .registers 19

    .line 1
    move-object/from16 v1, p1

    .line 2
    .line 3
    move-object/from16 v2, p2

    .line 4
    .line 5
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetTop()I

    .line 6
    .line 7
    .line 8
    move-result v3

    .line 9
    move-object/from16 v4, p0

    .line 10
    .line 11
    iget-object v5, v4, Landroidx/appcompat/app/AppCompatDelegateImpl$3;->this$0:Landroidx/appcompat/app/AppCompatDelegateImpl;

    .line 12
    .line 13
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetTop()I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;

    .line 21
    .line 22
    const/4 v7, 0x0

    .line 23
    const/16 v8, 0x8

    .line 24
    .line 25
    if-eqz v0, :cond_14b

    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    instance-of v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 32
    .line 33
    if-eqz v0, :cond_14b

    .line 34
    .line 35
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;

    .line 36
    .line 37
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    move-object v9, v0

    .line 42
    check-cast v9, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 43
    .line 44
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;

    .line 45
    .line 46
    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    const/4 v10, 0x1

    .line 51
    if-eqz v0, :cond_138

    .line 52
    .line 53
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mTempRect1:Landroid/graphics/Rect;

    .line 54
    .line 55
    if-nez v0, :cond_46

    .line 56
    .line 57
    new-instance v0, Landroid/graphics/Rect;

    .line 58
    .line 59
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 60
    .line 61
    .line 62
    iput-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mTempRect1:Landroid/graphics/Rect;

    .line 63
    .line 64
    new-instance v0, Landroid/graphics/Rect;

    .line 65
    .line 66
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 67
    .line 68
    .line 69
    iput-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mTempRect2:Landroid/graphics/Rect;

    .line 70
    .line 71
    :cond_46
    iget-object v11, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mTempRect1:Landroid/graphics/Rect;

    .line 72
    .line 73
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mTempRect2:Landroid/graphics/Rect;

    .line 74
    .line 75
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetLeft()I

    .line 76
    .line 77
    .line 78
    move-result v12

    .line 79
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetTop()I

    .line 80
    .line 81
    .line 82
    move-result v13

    .line 83
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetRight()I

    .line 84
    .line 85
    .line 86
    move-result v14

    .line 87
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetBottom()I

    .line 88
    .line 89
    .line 90
    move-result v15

    .line 91
    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/graphics/Rect;->set(IIII)V

    .line 92
    .line 93
    .line 94
    iget-object v12, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mSubDecor:Landroid/view/ViewGroup;

    .line 95
    .line 96
    sget-object v13, Landroidx/appcompat/widget/ViewUtils;->sComputeFitSystemWindowsMethod:Ljava/lang/reflect/Method;

    .line 97
    .line 98
    if-eqz v13, :cond_76

    .line 99
    .line 100
    const/4 v14, 0x2

    .line 101
    :try_start_64
    new-array v14, v14, [Ljava/lang/Object;

    .line 102
    .line 103
    aput-object v11, v14, v7

    .line 104
    .line 105
    aput-object v0, v14, v10

    .line 106
    .line 107
    invoke-virtual {v13, v12, v14}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_6d
    .catch Ljava/lang/Exception; {:try_start_64 .. :try_end_6d} :catch_6e

    .line 108
    .line 109
    .line 110
    goto :goto_76

    .line 111
    :catch_6e
    move-exception v0

    .line 112
    const-string v12, "ViewUtils"

    .line 113
    .line 114
    const-string v13, "Could not invoke computeFitSystemWindows"

    .line 115
    .line 116
    invoke-static {v12, v13, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 117
    .line 118
    .line 119
    :cond_76
    :goto_76
    iget v0, v11, Landroid/graphics/Rect;->top:I

    .line 120
    .line 121
    iget v12, v11, Landroid/graphics/Rect;->left:I

    .line 122
    .line 123
    iget v11, v11, Landroid/graphics/Rect;->right:I

    .line 124
    .line 125
    iget-object v13, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mSubDecor:Landroid/view/ViewGroup;

    .line 126
    .line 127
    sget-object v14, Landroidx/core/view/ViewCompat;->sViewPropertyAnimatorMap:Ljava/util/WeakHashMap;

    .line 128
    .line 129
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 130
    .line 131
    const/16 v15, 0x17

    .line 132
    .line 133
    if-lt v14, v15, :cond_8b

    .line 134
    .line 135
    invoke-static {v13}, Landroidx/core/view/ViewCompat$Api23Impl;->getRootWindowInsets(Landroid/view/View;)Landroidx/core/view/WindowInsetsCompat;

    .line 136
    .line 137
    .line 138
    move-result-object v13

    .line 139
    goto :goto_8f

    .line 140
    :cond_8b
    invoke-static {v13}, Landroidx/core/view/ViewCompat$Api21Impl;->getRootWindowInsets(Landroid/view/View;)Landroidx/core/view/WindowInsetsCompat;

    .line 141
    .line 142
    .line 143
    move-result-object v13

    .line 144
    :goto_8f
    if-nez v13, :cond_93

    .line 145
    .line 146
    const/4 v14, 0x0

    .line 147
    goto :goto_97

    .line 148
    :cond_93
    invoke-virtual {v13}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetLeft()I

    .line 149
    .line 150
    .line 151
    move-result v14

    .line 152
    :goto_97
    if-nez v13, :cond_9b

    .line 153
    .line 154
    const/4 v13, 0x0

    .line 155
    goto :goto_9f

    .line 156
    :cond_9b
    invoke-virtual {v13}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetRight()I

    .line 157
    .line 158
    .line 159
    move-result v13

    .line 160
    :goto_9f
    iget v15, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 161
    .line 162
    if-ne v15, v0, :cond_ae

    .line 163
    .line 164
    iget v15, v9, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 165
    .line 166
    if-ne v15, v12, :cond_ae

    .line 167
    .line 168
    iget v15, v9, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 169
    .line 170
    if-eq v15, v11, :cond_ac

    .line 171
    .line 172
    goto :goto_ae

    .line 173
    :cond_ac
    const/4 v11, 0x0

    .line 174
    goto :goto_b5

    .line 175
    :cond_ae
    :goto_ae
    iput v0, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 176
    .line 177
    iput v12, v9, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 178
    .line 179
    iput v11, v9, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 180
    .line 181
    const/4 v11, 0x1

    .line 182
    :goto_b5
    iget-object v12, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mContext:Landroid/content/Context;

    .line 183
    .line 184
    if-lez v0, :cond_dd

    .line 185
    .line 186
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 187
    .line 188
    if-nez v0, :cond_dd

    .line 189
    .line 190
    new-instance v0, Landroid/view/View;

    .line 191
    .line 192
    invoke-direct {v0, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 193
    .line 194
    .line 195
    iput-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 196
    .line 197
    invoke-virtual {v0, v8}, Landroid/view/View;->setVisibility(I)V

    .line 198
    .line 199
    .line 200
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 201
    .line 202
    iget v15, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 203
    .line 204
    const/16 v8, 0x33

    .line 205
    .line 206
    const/4 v10, -0x1

    .line 207
    invoke-direct {v0, v10, v15, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 208
    .line 209
    .line 210
    iput v14, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 211
    .line 212
    iput v13, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 213
    .line 214
    iget-object v8, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mSubDecor:Landroid/view/ViewGroup;

    .line 215
    .line 216
    iget-object v13, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 217
    .line 218
    invoke-virtual {v8, v13, v10, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 219
    .line 220
    .line 221
    goto :goto_100

    .line 222
    :cond_dd
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 223
    .line 224
    if-eqz v0, :cond_100

    .line 225
    .line 226
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 231
    .line 232
    iget v8, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 233
    .line 234
    iget v10, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 235
    .line 236
    if-ne v8, v10, :cond_f5

    .line 237
    .line 238
    iget v8, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 239
    .line 240
    if-ne v8, v14, :cond_f5

    .line 241
    .line 242
    iget v8, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 243
    .line 244
    if-eq v8, v13, :cond_100

    .line 245
    .line 246
    :cond_f5
    iput v10, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 247
    .line 248
    iput v14, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 249
    .line 250
    iput v13, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 251
    .line 252
    iget-object v8, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 253
    .line 254
    invoke-virtual {v8, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 255
    .line 256
    .line 257
    :cond_100
    :goto_100
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 258
    .line 259
    if-eqz v0, :cond_106

    .line 260
    .line 261
    const/4 v8, 0x1

    .line 262
    goto :goto_107

    .line 263
    :cond_106
    const/4 v8, 0x0

    .line 264
    :goto_107
    if-eqz v8, :cond_130

    .line 265
    .line 266
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 267
    .line 268
    .line 269
    move-result v0

    .line 270
    if-eqz v0, :cond_130

    .line 271
    .line 272
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 273
    .line 274
    invoke-static {v0}, Landroidx/core/view/ViewCompat$Api16Impl;->getWindowSystemUiVisibility(Landroid/view/View;)I

    .line 275
    .line 276
    .line 277
    move-result v10

    .line 278
    and-int/lit16 v10, v10, 0x2000

    .line 279
    .line 280
    if-eqz v10, :cond_11b

    .line 281
    .line 282
    const/4 v10, 0x1

    .line 283
    goto :goto_11c

    .line 284
    :cond_11b
    const/4 v10, 0x0

    .line 285
    :goto_11c
    if-eqz v10, :cond_126

    .line 286
    .line 287
    const v10, 0x7f050006

    .line 288
    .line 289
    .line 290
    invoke-static {v12, v10}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    .line 291
    .line 292
    .line 293
    move-result v10

    .line 294
    goto :goto_12d

    .line 295
    :cond_126
    const v10, 0x7f050005

    .line 296
    .line 297
    .line 298
    invoke-static {v12, v10}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    .line 299
    .line 300
    .line 301
    move-result v10

    .line 302
    :goto_12d
    invoke-virtual {v0, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 303
    .line 304
    .line 305
    :cond_130
    iget-boolean v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mOverlayActionMode:Z

    .line 306
    .line 307
    if-nez v0, :cond_143

    .line 308
    .line 309
    if-eqz v8, :cond_143

    .line 310
    .line 311
    const/4 v6, 0x0

    .line 312
    goto :goto_143

    .line 313
    :cond_138
    iget v0, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 314
    .line 315
    if-eqz v0, :cond_140

    .line 316
    .line 317
    iput v7, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 318
    .line 319
    const/4 v10, 0x1

    .line 320
    goto :goto_141

    .line 321
    :cond_140
    const/4 v10, 0x0

    .line 322
    :goto_141
    move v11, v10

    .line 323
    const/4 v8, 0x0

    .line 324
    :cond_143
    :goto_143
    if-eqz v11, :cond_14c

    .line 325
    .line 326
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;

    .line 327
    .line 328
    invoke-virtual {v0, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 329
    .line 330
    .line 331
    goto :goto_14c

    .line 332
    :cond_14b
    const/4 v8, 0x0

    .line 333
    :cond_14c
    :goto_14c
    iget-object v0, v5, Landroidx/appcompat/app/AppCompatDelegateImpl;->mStatusGuard:Landroid/view/View;

    .line 334
    .line 335
    if-eqz v0, :cond_158

    .line 336
    .line 337
    if-eqz v8, :cond_153

    .line 338
    .line 339
    goto :goto_155

    .line 340
    :cond_153
    const/16 v7, 0x8

    .line 341
    .line 342
    :goto_155
    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    .line 343
    .line 344
    .line 345
    :cond_158
    if-eq v3, v6, :cond_18d

    .line 346
    .line 347
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetLeft()I

    .line 348
    .line 349
    .line 350
    move-result v0

    .line 351
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetRight()I

    .line 352
    .line 353
    .line 354
    move-result v3

    .line 355
    invoke-virtual/range {p2 .. p2}, Landroidx/core/view/WindowInsetsCompat;->getSystemWindowInsetBottom()I

    .line 356
    .line 357
    .line 358
    move-result v5

    .line 359
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 360
    .line 361
    const/16 v8, 0x1e

    .line 362
    .line 363
    if-lt v7, v8, :cond_172

    .line 364
    .line 365
    new-instance v7, Landroidx/core/view/WindowInsetsCompat$BuilderImpl30;

    .line 366
    .line 367
    invoke-direct {v7, v2}, Landroidx/core/view/WindowInsetsCompat$BuilderImpl30;-><init>(Landroidx/core/view/WindowInsetsCompat;)V

    .line 368
    .line 369
    .line 370
    goto :goto_181

    .line 371
    :cond_172
    const/16 v8, 0x1d

    .line 372
    .line 373
    if-lt v7, v8, :cond_17c

    .line 374
    .line 375
    new-instance v7, Landroidx/core/view/WindowInsetsCompat$BuilderImpl29;

    .line 376
    .line 377
    invoke-direct {v7, v2}, Landroidx/core/view/WindowInsetsCompat$BuilderImpl29;-><init>(Landroidx/core/view/WindowInsetsCompat;)V

    .line 378
    .line 379
    .line 380
    goto :goto_181

    .line 381
    :cond_17c
    new-instance v7, Landroidx/core/view/WindowInsetsCompat$BuilderImpl20;

    .line 382
    .line 383
    invoke-direct {v7, v2}, Landroidx/core/view/WindowInsetsCompat$BuilderImpl20;-><init>(Landroidx/core/view/WindowInsetsCompat;)V

    .line 384
    .line 385
    .line 386
    :goto_181
    invoke-static {v0, v6, v3, v5}, Landroidx/core/graphics/Insets;->of(IIII)Landroidx/core/graphics/Insets;

    .line 387
    .line 388
    .line 389
    move-result-object v0

    .line 390
    invoke-virtual {v7, v0}, Landroidx/core/view/WindowInsetsCompat$BuilderImpl;->setSystemWindowInsets(Landroidx/core/graphics/Insets;)V

    .line 391
    .line 392
    .line 393
    invoke-virtual {v7}, Landroidx/core/view/WindowInsetsCompat$BuilderImpl;->build()Landroidx/core/view/WindowInsetsCompat;

    .line 394
    .line 395
    .line 396
    move-result-object v0

    .line 397
    goto :goto_18e

    .line 398
    :cond_18d
    move-object v0, v2

    .line 399
    :goto_18e
    sget-object v2, Landroidx/core/view/ViewCompat;->sViewPropertyAnimatorMap:Ljava/util/WeakHashMap;

    .line 400
    .line 401
    invoke-virtual {v0}, Landroidx/core/view/WindowInsetsCompat;->toWindowInsets()Landroid/view/WindowInsets;

    .line 402
    .line 403
    .line 404
    move-result-object v2

    .line 405
    if-eqz v2, :cond_1a4

    .line 406
    .line 407
    invoke-static {v1, v2}, Landroidx/core/view/ViewCompat$Api20Impl;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 408
    .line 409
    .line 410
    move-result-object v3

    .line 411
    invoke-virtual {v3, v2}, Landroid/view/WindowInsets;->equals(Ljava/lang/Object;)Z

    .line 412
    .line 413
    .line 414
    move-result v2

    .line 415
    if-nez v2, :cond_1a4

    .line 416
    .line 417
    invoke-static {v3, v1}, Landroidx/core/view/WindowInsetsCompat;->toWindowInsetsCompat(Landroid/view/WindowInsets;Landroid/view/View;)Landroidx/core/view/WindowInsetsCompat;

    .line 418
    .line 419
    .line 420
    move-result-object v0

    .line 421
    :cond_1a4
    return-object v0
.end method
