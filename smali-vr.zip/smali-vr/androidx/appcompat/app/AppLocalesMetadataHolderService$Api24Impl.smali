.class public final Landroidx/appcompat/app/AppLocalesMetadataHolderService$Api24Impl;
.super Ljava/lang/Object;
.source "AppLocalesMetadataHolderService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/app/AppLocalesMetadataHolderService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Api24Impl"
.end annotation


# direct methods
.method public static getDisabledComponentFlag()I
    .registers 1

    .line 1
    const/16 v0, 0x200

    .line 2
    .line 3
    return v0
.end method
