.class public final Landroidx/appcompat/app/ResourcesFlusher$Api16Impl;
.super Ljava/lang/Object;
.source "ResourcesFlusher.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/app/ResourcesFlusher;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Api16Impl"
.end annotation


# direct methods
.method public static clear(Landroid/util/LongSparseArray;)V
    .registers 1

    .line 1
    invoke-virtual {p0}, Landroid/util/LongSparseArray;->clear()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
