.class public final synthetic Landroidx/appcompat/graphics/drawable/DrawerArrowDrawable$$ExternalSyntheticOutline0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static m(FFFF)F
    .registers 4

    .line 1
    sub-float/2addr p0, p1

    .line 2
    mul-float p0, p0, p2

    .line 3
    .line 4
    add-float/2addr p0, p3

    .line 5
    return p0
.end method
