.class public final Landroidx/appcompat/resources/Compatibility$Api18Impl;
.super Ljava/lang/Object;
.source "Compatibility.java"


# direct methods
.method public static setAutoCancel(Landroid/animation/ObjectAnimator;Z)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroid/animation/ObjectAnimator;->setAutoCancel(Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
