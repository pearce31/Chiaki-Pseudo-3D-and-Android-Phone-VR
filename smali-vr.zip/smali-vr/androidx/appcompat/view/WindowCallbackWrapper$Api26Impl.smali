.class public final Landroidx/appcompat/view/WindowCallbackWrapper$Api26Impl;
.super Ljava/lang/Object;
.source "WindowCallbackWrapper.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/WindowCallbackWrapper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Api26Impl"
.end annotation


# direct methods
.method public static onPointerCaptureChanged(Landroid/view/Window$Callback;Z)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, Landroidx/core/view/ViewCompat$Api26Impl$$ExternalSyntheticApiModelOutline5;->m(Landroid/view/Window$Callback;Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
