.class public final Landroidx/appcompat/widget/AppCompatSpinner$Api23Impl;
.super Ljava/lang/Object;
.source "AppCompatSpinner.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/AppCompatSpinner;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Api23Impl"
.end annotation


# direct methods
.method public static setDropDownViewTheme(Landroid/widget/ThemedSpinnerAdapter;Landroid/content/res/Resources$Theme;)V
    .registers 3

    .line 1
    invoke-static {p0}, Landroidx/core/widget/TextViewCompat$Api23Impl$$ExternalSyntheticApiModelOutline5;->m(Landroid/widget/ThemedSpinnerAdapter;)Landroid/content/res/Resources$Theme;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, Landroidx/core/util/ObjectsCompat$Api19Impl;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_d

    .line 10
    .line 11
    invoke-static {p0, p1}, Landroidx/appcompat/widget/AppCompatSpinner$Api23Impl$$ExternalSyntheticApiModelOutline1;->m(Landroid/widget/ThemedSpinnerAdapter;Landroid/content/res/Resources$Theme;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method
