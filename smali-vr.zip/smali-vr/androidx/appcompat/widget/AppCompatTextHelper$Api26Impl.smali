.class public final Landroidx/appcompat/widget/AppCompatTextHelper$Api26Impl;
.super Ljava/lang/Object;
.source "AppCompatTextHelper.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/AppCompatTextHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Api26Impl"
.end annotation


# direct methods
.method public static getAutoSizeStepGranularity(Landroid/widget/TextView;)I
    .registers 1

    .line 1
    invoke-static {p0}, Landroidx/core/view/MenuItemCompat$Api26Impl$$ExternalSyntheticApiModelOutline4;->m(Landroid/widget/TextView;)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static setAutoSizeTextTypeUniformWithConfiguration(Landroid/widget/TextView;IIII)V
    .registers 5

    .line 1
    invoke-static {p0, p1, p2, p3, p4}, Landroidx/core/view/MenuItemCompat$Api26Impl$$ExternalSyntheticApiModelOutline3;->m(Landroid/widget/TextView;IIII)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static setAutoSizeTextTypeUniformWithPresetSizes(Landroid/widget/TextView;[II)V
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, Landroidx/core/view/MenuItemCompat$Api26Impl$$ExternalSyntheticApiModelOutline5;->m(Landroid/widget/TextView;[II)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static setFontVariationSettings(Landroid/widget/TextView;Ljava/lang/String;)Z
    .registers 2

    .line 1
    invoke-static {p0, p1}, Landroidx/core/view/MenuItemCompat$Api26Impl$$ExternalSyntheticApiModelOutline2;->m(Landroid/widget/TextView;Ljava/lang/String;)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method
