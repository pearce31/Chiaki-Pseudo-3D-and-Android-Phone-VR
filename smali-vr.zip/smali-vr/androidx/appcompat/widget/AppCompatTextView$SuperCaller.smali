.class public interface abstract Landroidx/appcompat/widget/AppCompatTextView$SuperCaller;
.super Ljava/lang/Object;
.source "AppCompatTextView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/AppCompatTextView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SuperCaller"
.end annotation


# virtual methods
.method public abstract setFirstBaselineToTopHeight(I)V
.end method

.method public abstract setLastBaselineToBottomHeight(I)V
.end method
