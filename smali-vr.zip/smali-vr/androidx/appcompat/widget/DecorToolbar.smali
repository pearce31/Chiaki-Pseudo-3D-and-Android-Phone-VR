.class public interface abstract Landroidx/appcompat/widget/DecorToolbar;
.super Ljava/lang/Object;
.source "DecorToolbar.java"


# virtual methods
.method public abstract canShowOverflowMenu()Z
.end method

.method public abstract collapseActionView()V
.end method

.method public abstract dismissPopupMenus()V
.end method

.method public abstract getContext()Landroid/content/Context;
.end method

.method public abstract getDisplayOptions()I
.end method

.method public abstract getNavigationMode()V
.end method

.method public abstract getTitle()Ljava/lang/CharSequence;
.end method

.method public abstract hasExpandedActionView()Z
.end method

.method public abstract hideOverflowMenu()Z
.end method

.method public abstract initIndeterminateProgress()V
.end method

.method public abstract initProgress()V
.end method

.method public abstract isOverflowMenuShowPending()Z
.end method

.method public abstract isOverflowMenuShowing()Z
.end method

.method public abstract setCollapsible(Z)V
.end method

.method public abstract setDisplayOptions(I)V
.end method

.method public abstract setEmbeddedTabView()V
.end method

.method public abstract setHomeButtonEnabled()V
.end method

.method public abstract setIcon(I)V
.end method

.method public abstract setIcon(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract setLogo(I)V
.end method

.method public abstract setMenu(Landroidx/appcompat/view/menu/MenuBuilder;Landroidx/appcompat/app/AppCompatDelegateImpl$ActionMenuPresenterCallback;)V
.end method

.method public abstract setMenuPrepared()V
.end method

.method public abstract setVisibility(I)V
.end method

.method public abstract setWindowCallback(Landroid/view/Window$Callback;)V
.end method

.method public abstract setWindowTitle(Ljava/lang/CharSequence;)V
.end method

.method public abstract setupAnimatorToVisibility(IJ)Landroidx/core/view/ViewPropertyAnimatorCompat;
.end method

.method public abstract showOverflowMenu()Z
.end method
