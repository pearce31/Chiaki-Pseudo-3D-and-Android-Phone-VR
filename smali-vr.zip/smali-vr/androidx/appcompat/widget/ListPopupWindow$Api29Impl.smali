.class public final Landroidx/appcompat/widget/ListPopupWindow$Api29Impl;
.super Ljava/lang/Object;
.source "ListPopupWindow.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/ListPopupWindow;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Api29Impl"
.end annotation


# direct methods
.method public static setEpicenterBounds(Landroid/widget/PopupWindow;Landroid/graphics/Rect;)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, Landroidx/appcompat/widget/ListPopupWindow$Api29Impl$$ExternalSyntheticApiModelOutline0;->m(Landroid/widget/PopupWindow;Landroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static setIsClippedToScreen(Landroid/widget/PopupWindow;Z)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, Landroidx/appcompat/widget/ListPopupWindow$Api29Impl$$ExternalSyntheticApiModelOutline1;->m(Landroid/widget/PopupWindow;Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
