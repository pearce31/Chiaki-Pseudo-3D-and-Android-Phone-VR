.class public interface abstract Landroidx/appcompat/widget/ThemedSpinnerAdapter;
.super Ljava/lang/Object;
.source "ThemedSpinnerAdapter.java"

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method

.method public abstract setDropDownViewTheme()V
.end method
