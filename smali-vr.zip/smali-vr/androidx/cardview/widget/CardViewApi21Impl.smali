.class public final Landroidx/cardview/widget/CardViewApi21Impl;
.super Ljava/lang/Object;
.source "CardViewApi21Impl.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final setMaxElevation(Landroidx/cardview/widget/CardViewDelegate;F)V
    .registers 12

    .line 1
    check-cast p1, Landroidx/cardview/widget/CardView$1;

    .line 2
    .line 3
    iget-object v0, p1, Landroidx/cardview/widget/CardView$1;->mCardBackground:Landroid/graphics/drawable/Drawable;

    .line 4
    .line 5
    check-cast v0, Landroidx/cardview/widget/RoundRectDrawable;

    .line 6
    .line 7
    iget-object v1, p1, Landroidx/cardview/widget/CardView$1;->this$0:Landroidx/cardview/widget/CardView;

    .line 8
    .line 9
    invoke-virtual {v1}, Landroidx/cardview/widget/CardView;->getUseCompatPadding()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    iget-object v2, p1, Landroidx/cardview/widget/CardView$1;->this$0:Landroidx/cardview/widget/CardView;

    .line 14
    .line 15
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getPreventCornerOverlap()Z

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    iget v4, v0, Landroidx/cardview/widget/RoundRectDrawable;->mPadding:F

    .line 20
    .line 21
    cmpl-float v4, p2, v4

    .line 22
    .line 23
    if-nez v4, :cond_21

    .line 24
    .line 25
    iget-boolean v4, v0, Landroidx/cardview/widget/RoundRectDrawable;->mInsetForPadding:Z

    .line 26
    .line 27
    if-ne v4, v1, :cond_21

    .line 28
    .line 29
    iget-boolean v4, v0, Landroidx/cardview/widget/RoundRectDrawable;->mInsetForRadius:Z

    .line 30
    .line 31
    if-ne v4, v3, :cond_21

    .line 32
    .line 33
    goto :goto_2e

    .line 34
    :cond_21
    iput p2, v0, Landroidx/cardview/widget/RoundRectDrawable;->mPadding:F

    .line 35
    .line 36
    iput-boolean v1, v0, Landroidx/cardview/widget/RoundRectDrawable;->mInsetForPadding:Z

    .line 37
    .line 38
    iput-boolean v3, v0, Landroidx/cardview/widget/RoundRectDrawable;->mInsetForRadius:Z

    .line 39
    .line 40
    const/4 p2, 0x0

    .line 41
    invoke-virtual {v0, p2}, Landroidx/cardview/widget/RoundRectDrawable;->updateBounds(Landroid/graphics/Rect;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 45
    .line 46
    .line 47
    :goto_2e
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getUseCompatPadding()Z

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    if-nez p2, :cond_39

    .line 52
    .line 53
    const/4 p2, 0x0

    .line 54
    invoke-virtual {p1, p2, p2, p2, p2}, Landroidx/cardview/widget/CardView$1;->setShadowPadding(IIII)V

    .line 55
    .line 56
    .line 57
    goto :goto_70

    .line 58
    :cond_39
    iget-object p2, p1, Landroidx/cardview/widget/CardView$1;->mCardBackground:Landroid/graphics/drawable/Drawable;

    .line 59
    .line 60
    move-object v0, p2

    .line 61
    check-cast v0, Landroidx/cardview/widget/RoundRectDrawable;

    .line 62
    .line 63
    iget v0, v0, Landroidx/cardview/widget/RoundRectDrawable;->mPadding:F

    .line 64
    .line 65
    check-cast p2, Landroidx/cardview/widget/RoundRectDrawable;

    .line 66
    .line 67
    iget p2, p2, Landroidx/cardview/widget/RoundRectDrawable;->mRadius:F

    .line 68
    .line 69
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getPreventCornerOverlap()Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-eqz v1, :cond_56

    .line 74
    .line 75
    float-to-double v3, v0

    .line 76
    const-wide/high16 v5, 0x3ff0000000000000L    # 1.0

    .line 77
    .line 78
    sget-wide v7, Landroidx/cardview/widget/RoundRectDrawableWithShadow;->COS_45:D

    .line 79
    .line 80
    sub-double/2addr v5, v7

    .line 81
    float-to-double v7, p2

    .line 82
    mul-double v5, v5, v7

    .line 83
    .line 84
    add-double/2addr v5, v3

    .line 85
    double-to-float v1, v5

    .line 86
    goto :goto_59

    .line 87
    :cond_56
    sget v1, Landroidx/cardview/widget/RoundRectDrawableWithShadow;->$r8$clinit:I

    .line 88
    .line 89
    move v1, v0

    .line 90
    :goto_59
    float-to-double v3, v1

    .line 91
    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    .line 92
    .line 93
    .line 94
    move-result-wide v3

    .line 95
    double-to-int v1, v3

    .line 96
    invoke-virtual {v2}, Landroidx/cardview/widget/CardView;->getPreventCornerOverlap()Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    invoke-static {v0, p2, v2}, Landroidx/cardview/widget/RoundRectDrawableWithShadow;->calculateVerticalPadding(FFZ)F

    .line 101
    .line 102
    .line 103
    move-result p2

    .line 104
    float-to-double v2, p2

    .line 105
    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    .line 106
    .line 107
    .line 108
    move-result-wide v2

    .line 109
    double-to-int p2, v2

    .line 110
    invoke-virtual {p1, v1, p2, v1, p2}, Landroidx/cardview/widget/CardView$1;->setShadowPadding(IIII)V

    .line 111
    .line 112
    .line 113
    :goto_70
    return-void
.end method
