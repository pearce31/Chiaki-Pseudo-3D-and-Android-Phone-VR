.class public final synthetic Landroidx/constraintlayout/core/SolverVariable$Type$EnumUnboxingSharedUtility;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 0

    .line 1
    return-void
.end method

.method public static synthetic ordinal(I)I
    .registers 1

    .line 1
    if-eqz p0, :cond_5

    .line 2
    .line 3
    add-int/lit8 p0, p0, -0x1

    .line 4
    .line 5
    return p0

    .line 6
    :cond_5
    const/4 p0, 0x0

    .line 7
    throw p0
.end method
