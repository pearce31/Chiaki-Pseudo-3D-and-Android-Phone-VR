.class public final Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
.super Landroidx/constraintlayout/core/widgets/WidgetContainer;
.source "ConstraintWidgetContainer.java"


# instance fields
.field public horizontalWrapMax:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/constraintlayout/core/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation
.end field

.field public horizontalWrapMin:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/constraintlayout/core/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation
.end field

.field public final mBasicMeasureSolver:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure;

.field public final mDependencyGraph:Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;

.field public mHeightMeasuredTooSmall:Z

.field public mHorizontalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

.field public mHorizontalChainsSize:I

.field public mIsRtl:Z

.field public final mMeasure:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;

.field public mMeasurer:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;

.field public mOptimizationLevel:I

.field public mPaddingLeft:I

.field public mPaddingTop:I

.field public final mSystem:Landroidx/constraintlayout/core/LinearSystem;

.field public mVerticalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

.field public mVerticalChainsSize:I

.field public mWidthMeasuredTooSmall:Z

.field public pass:I

.field public verticalWrapMax:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/constraintlayout/core/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation
.end field

.field public verticalWrapMin:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/constraintlayout/core/widgets/ConstraintAnchor;",
            ">;"
        }
    .end annotation
.end field

.field public final widgetsToAdd:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Landroidx/constraintlayout/core/widgets/ConstraintWidget;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 5

    .line 1
    invoke-direct {p0}, Landroidx/constraintlayout/core/widgets/WidgetContainer;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure;-><init>(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mBasicMeasureSolver:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure;

    .line 10
    .line 11
    new-instance v0, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;

    .line 12
    .line 13
    invoke-direct {v0, p0}, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;-><init>(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mDependencyGraph:Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mMeasurer:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    iput-boolean v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mIsRtl:Z

    .line 23
    .line 24
    new-instance v2, Landroidx/constraintlayout/core/LinearSystem;

    .line 25
    .line 26
    invoke-direct {v2}, Landroidx/constraintlayout/core/LinearSystem;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object v2, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mSystem:Landroidx/constraintlayout/core/LinearSystem;

    .line 30
    .line 31
    iput v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 32
    .line 33
    iput v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 34
    .line 35
    const/4 v2, 0x4

    .line 36
    new-array v3, v2, [Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 37
    .line 38
    iput-object v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 39
    .line 40
    new-array v2, v2, [Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 41
    .line 42
    iput-object v2, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 43
    .line 44
    const/16 v2, 0x101

    .line 45
    .line 46
    iput v2, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mOptimizationLevel:I

    .line 47
    .line 48
    iput-boolean v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mWidthMeasuredTooSmall:Z

    .line 49
    .line 50
    iput-boolean v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHeightMeasuredTooSmall:Z

    .line 51
    .line 52
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMin:Ljava/lang/ref/WeakReference;

    .line 53
    .line 54
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMin:Ljava/lang/ref/WeakReference;

    .line 55
    .line 56
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMax:Ljava/lang/ref/WeakReference;

    .line 57
    .line 58
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMax:Ljava/lang/ref/WeakReference;

    .line 59
    .line 60
    new-instance v0, Ljava/util/HashSet;

    .line 61
    .line 62
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 63
    .line 64
    .line 65
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->widgetsToAdd:Ljava/util/HashSet;

    .line 66
    .line 67
    new-instance v0, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;

    .line 68
    .line 69
    invoke-direct {v0}, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;-><init>()V

    .line 70
    .line 71
    .line 72
    iput-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mMeasure:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;

    .line 73
    .line 74
    return-void
.end method

.method public static measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V
    .registers 12

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    iget v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mVisibility:I

    .line 5
    .line 6
    const/16 v1, 0x8

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    if-eq v0, v1, :cond_116

    .line 10
    .line 11
    instance-of v0, p0, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 12
    .line 13
    if-nez v0, :cond_116

    .line 14
    .line 15
    instance-of v0, p0, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 16
    .line 17
    if-eqz v0, :cond_14

    .line 18
    .line 19
    goto/16 :goto_116

    .line 20
    .line 21
    :cond_14
    iget-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 22
    .line 23
    aget v1, v0, v2

    .line 24
    .line 25
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    aget v0, v0, v1

    .line 29
    .line 30
    iput v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 31
    .line 32
    invoke-virtual {p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    iput v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalDimension:I

    .line 37
    .line 38
    invoke-virtual {p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    iput v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalDimension:I

    .line 43
    .line 44
    iput-boolean v2, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredNeedsSolverPass:Z

    .line 45
    .line 46
    iput v2, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measureStrategy:I

    .line 47
    .line 48
    iget v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 49
    .line 50
    const/4 v3, 0x3

    .line 51
    if-ne v0, v3, :cond_36

    .line 52
    .line 53
    const/4 v0, 0x1

    .line 54
    goto :goto_37

    .line 55
    :cond_36
    const/4 v0, 0x0

    .line 56
    :goto_37
    iget v4, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 57
    .line 58
    if-ne v4, v3, :cond_3d

    .line 59
    .line 60
    const/4 v3, 0x1

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    const/4 v3, 0x0

    .line 63
    :goto_3e
    const/4 v4, 0x0

    .line 64
    if-eqz v0, :cond_49

    .line 65
    .line 66
    iget v5, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mDimensionRatio:F

    .line 67
    .line 68
    cmpl-float v5, v5, v4

    .line 69
    .line 70
    if-lez v5, :cond_49

    .line 71
    .line 72
    const/4 v5, 0x1

    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    const/4 v5, 0x0

    .line 75
    :goto_4a
    if-eqz v3, :cond_54

    .line 76
    .line 77
    iget v6, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mDimensionRatio:F

    .line 78
    .line 79
    cmpl-float v4, v6, v4

    .line 80
    .line 81
    if-lez v4, :cond_54

    .line 82
    .line 83
    const/4 v4, 0x1

    .line 84
    goto :goto_55

    .line 85
    :cond_54
    const/4 v4, 0x0

    .line 86
    :goto_55
    const/4 v6, 0x2

    .line 87
    if-eqz v0, :cond_6f

    .line 88
    .line 89
    invoke-virtual {p0, v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->hasDanglingDimension(I)Z

    .line 90
    .line 91
    .line 92
    move-result v7

    .line 93
    if-eqz v7, :cond_6f

    .line 94
    .line 95
    iget v7, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMatchConstraintDefaultWidth:I

    .line 96
    .line 97
    if-nez v7, :cond_6f

    .line 98
    .line 99
    if-nez v5, :cond_6f

    .line 100
    .line 101
    iput v6, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 102
    .line 103
    if-eqz v3, :cond_6e

    .line 104
    .line 105
    iget v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMatchConstraintDefaultHeight:I

    .line 106
    .line 107
    if-nez v0, :cond_6e

    .line 108
    .line 109
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 110
    .line 111
    :cond_6e
    const/4 v0, 0x0

    .line 112
    :cond_6f
    if-eqz v3, :cond_88

    .line 113
    .line 114
    invoke-virtual {p0, v1}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->hasDanglingDimension(I)Z

    .line 115
    .line 116
    .line 117
    move-result v7

    .line 118
    if-eqz v7, :cond_88

    .line 119
    .line 120
    iget v7, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMatchConstraintDefaultHeight:I

    .line 121
    .line 122
    if-nez v7, :cond_88

    .line 123
    .line 124
    if-nez v4, :cond_88

    .line 125
    .line 126
    iput v6, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 127
    .line 128
    if-eqz v0, :cond_87

    .line 129
    .line 130
    iget v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMatchConstraintDefaultWidth:I

    .line 131
    .line 132
    if-nez v3, :cond_87

    .line 133
    .line 134
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 135
    .line 136
    :cond_87
    const/4 v3, 0x0

    .line 137
    :cond_88
    invoke-virtual {p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isResolvedHorizontally()Z

    .line 138
    .line 139
    .line 140
    move-result v7

    .line 141
    if-eqz v7, :cond_91

    .line 142
    .line 143
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 144
    .line 145
    const/4 v0, 0x0

    .line 146
    :cond_91
    invoke-virtual {p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isResolvedVertically()Z

    .line 147
    .line 148
    .line 149
    move-result v7

    .line 150
    if-eqz v7, :cond_9a

    .line 151
    .line 152
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 153
    .line 154
    const/4 v3, 0x0

    .line 155
    :cond_9a
    const/4 v7, 0x4

    .line 156
    iget-object v8, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mResolvedMatchConstraintDefault:[I

    .line 157
    .line 158
    if-eqz v5, :cond_c3

    .line 159
    .line 160
    aget v5, v8, v2

    .line 161
    .line 162
    if-ne v5, v7, :cond_a6

    .line 163
    .line 164
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 165
    .line 166
    goto :goto_c3

    .line 167
    :cond_a6
    if-nez v3, :cond_c3

    .line 168
    .line 169
    iget v3, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 170
    .line 171
    if-ne v3, v1, :cond_af

    .line 172
    .line 173
    iget v3, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalDimension:I

    .line 174
    .line 175
    goto :goto_b9

    .line 176
    :cond_af
    iput v6, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 177
    .line 178
    move-object v3, p1

    .line 179
    check-cast v3, Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;

    .line 180
    .line 181
    invoke-virtual {v3, p0, p2}, Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;->measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V

    .line 182
    .line 183
    .line 184
    iget v3, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredHeight:I

    .line 185
    .line 186
    :goto_b9
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 187
    .line 188
    iget v5, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mDimensionRatio:F

    .line 189
    .line 190
    int-to-float v3, v3

    .line 191
    mul-float v5, v5, v3

    .line 192
    .line 193
    float-to-int v3, v5

    .line 194
    iput v3, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalDimension:I

    .line 195
    .line 196
    :cond_c3
    :goto_c3
    if-eqz v4, :cond_f6

    .line 197
    .line 198
    aget v3, v8, v1

    .line 199
    .line 200
    if-ne v3, v7, :cond_cc

    .line 201
    .line 202
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 203
    .line 204
    goto :goto_f6

    .line 205
    :cond_cc
    if-nez v0, :cond_f6

    .line 206
    .line 207
    iget v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalBehavior:I

    .line 208
    .line 209
    if-ne v0, v1, :cond_d5

    .line 210
    .line 211
    iget v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->horizontalDimension:I

    .line 212
    .line 213
    goto :goto_df

    .line 214
    :cond_d5
    iput v6, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 215
    .line 216
    move-object v0, p1

    .line 217
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;

    .line 218
    .line 219
    invoke-virtual {v0, p0, p2}, Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;->measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V

    .line 220
    .line 221
    .line 222
    iget v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredWidth:I

    .line 223
    .line 224
    :goto_df
    iput v1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalBehavior:I

    .line 225
    .line 226
    iget v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mDimensionRatioSide:I

    .line 227
    .line 228
    const/4 v4, -0x1

    .line 229
    if-ne v3, v4, :cond_ee

    .line 230
    .line 231
    int-to-float v0, v0

    .line 232
    iget v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mDimensionRatio:F

    .line 233
    .line 234
    div-float/2addr v0, v3

    .line 235
    float-to-int v0, v0

    .line 236
    iput v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalDimension:I

    .line 237
    .line 238
    goto :goto_f6

    .line 239
    :cond_ee
    iget v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mDimensionRatio:F

    .line 240
    .line 241
    int-to-float v0, v0

    .line 242
    mul-float v3, v3, v0

    .line 243
    .line 244
    float-to-int v0, v3

    .line 245
    iput v0, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->verticalDimension:I

    .line 246
    .line 247
    :cond_f6
    :goto_f6
    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;

    .line 248
    .line 249
    invoke-virtual {p1, p0, p2}, Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;->measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V

    .line 250
    .line 251
    .line 252
    iget p1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredWidth:I

    .line 253
    .line 254
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 255
    .line 256
    .line 257
    iget p1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredHeight:I

    .line 258
    .line 259
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 260
    .line 261
    .line 262
    iget-boolean p1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredHasBaseline:Z

    .line 263
    .line 264
    iput-boolean p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->hasBaseline:Z

    .line 265
    .line 266
    iget p1, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredBaseline:I

    .line 267
    .line 268
    iput p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mBaselineDistance:I

    .line 269
    .line 270
    if-lez p1, :cond_110

    .line 271
    .line 272
    goto :goto_111

    .line 273
    :cond_110
    const/4 v1, 0x0

    .line 274
    :goto_111
    iput-boolean v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->hasBaseline:Z

    .line 275
    .line 276
    iput v2, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measureStrategy:I

    .line 277
    .line 278
    return-void

    .line 279
    :cond_116
    :goto_116
    iput v2, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredWidth:I

    .line 280
    .line 281
    iput v2, p2, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;->measuredHeight:I

    .line 282
    .line 283
    return-void
.end method


# virtual methods
.method public final addChain(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;)V
    .registers 8

    .line 1
    const/4 v0, 0x1

    .line 2
    if-nez p1, :cond_28

    .line 3
    .line 4
    iget p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 5
    .line 6
    add-int/2addr p1, v0

    .line 7
    iget-object v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 8
    .line 9
    array-length v2, v1

    .line 10
    if-lt p1, v2, :cond_16

    .line 11
    .line 12
    array-length p1, v1

    .line 13
    mul-int/lit8 p1, p1, 0x2

    .line 14
    .line 15
    invoke-static {v1, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, [Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 20
    .line 21
    iput-object p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 22
    .line 23
    :cond_16
    iget-object p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 24
    .line 25
    iget v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 26
    .line 27
    new-instance v2, Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 28
    .line 29
    iget-boolean v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mIsRtl:Z

    .line 30
    .line 31
    const/4 v4, 0x0

    .line 32
    invoke-direct {v2, p2, v4, v3}, Landroidx/constraintlayout/core/widgets/ChainHead;-><init>(Landroidx/constraintlayout/core/widgets/ConstraintWidget;IZ)V

    .line 33
    .line 34
    .line 35
    aput-object v2, p1, v1

    .line 36
    .line 37
    add-int/2addr v1, v0

    .line 38
    iput v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 39
    .line 40
    goto :goto_4d

    .line 41
    :cond_28
    if-ne p1, v0, :cond_4d

    .line 42
    .line 43
    iget p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 44
    .line 45
    add-int/2addr p1, v0

    .line 46
    iget-object v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 47
    .line 48
    array-length v2, v1

    .line 49
    if-lt p1, v2, :cond_3d

    .line 50
    .line 51
    array-length p1, v1

    .line 52
    mul-int/lit8 p1, p1, 0x2

    .line 53
    .line 54
    invoke-static {v1, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    check-cast p1, [Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 59
    .line 60
    iput-object p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 61
    .line 62
    :cond_3d
    iget-object p1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsArray:[Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 63
    .line 64
    iget v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 65
    .line 66
    new-instance v2, Landroidx/constraintlayout/core/widgets/ChainHead;

    .line 67
    .line 68
    iget-boolean v3, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mIsRtl:Z

    .line 69
    .line 70
    invoke-direct {v2, p2, v0, v3}, Landroidx/constraintlayout/core/widgets/ChainHead;-><init>(Landroidx/constraintlayout/core/widgets/ConstraintWidget;IZ)V

    .line 71
    .line 72
    .line 73
    aput-object v2, p1, v1

    .line 74
    .line 75
    add-int/2addr v1, v0

    .line 76
    iput v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 77
    .line 78
    :cond_4d
    :goto_4d
    return-void
.end method

.method public final addChildrenToSolver(Landroidx/constraintlayout/core/LinearSystem;)V
    .registers 14

    .line 1
    const/16 v0, 0x40

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->optimizeFor(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-virtual {p0, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v2, 0x0

    .line 17
    const/4 v3, 0x0

    .line 18
    const/4 v4, 0x0

    .line 19
    :goto_12
    const/4 v5, 0x1

    .line 20
    if-ge v3, v1, :cond_2b

    .line 21
    .line 22
    iget-object v6, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    check-cast v6, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 29
    .line 30
    iget-object v7, v6, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mIsInBarrier:[Z

    .line 31
    .line 32
    aput-boolean v2, v7, v2

    .line 33
    .line 34
    aput-boolean v2, v7, v5

    .line 35
    .line 36
    instance-of v6, v6, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 37
    .line 38
    if-eqz v6, :cond_28

    .line 39
    .line 40
    const/4 v4, 0x1

    .line 41
    :cond_28
    add-int/lit8 v3, v3, 0x1

    .line 42
    .line 43
    goto :goto_12

    .line 44
    :cond_2b
    const/4 v3, 0x2

    .line 45
    if-eqz v4, :cond_6e

    .line 46
    .line 47
    const/4 v4, 0x0

    .line 48
    :goto_2f
    if-ge v4, v1, :cond_6e

    .line 49
    .line 50
    iget-object v6, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 51
    .line 52
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v6

    .line 56
    check-cast v6, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 57
    .line 58
    instance-of v7, v6, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 59
    .line 60
    if-eqz v7, :cond_6b

    .line 61
    .line 62
    check-cast v6, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 63
    .line 64
    const/4 v7, 0x0

    .line 65
    :goto_40
    iget v8, v6, Landroidx/constraintlayout/core/widgets/HelperWidget;->mWidgetsCount:I

    .line 66
    .line 67
    if-ge v7, v8, :cond_6b

    .line 68
    .line 69
    iget-object v8, v6, Landroidx/constraintlayout/core/widgets/HelperWidget;->mWidgets:[Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 70
    .line 71
    aget-object v8, v8, v7

    .line 72
    .line 73
    iget-boolean v9, v6, Landroidx/constraintlayout/core/widgets/Barrier;->mAllowsGoneWidget:Z

    .line 74
    .line 75
    if-nez v9, :cond_53

    .line 76
    .line 77
    invoke-virtual {v8}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->allowedInBarrier()Z

    .line 78
    .line 79
    .line 80
    move-result v9

    .line 81
    if-nez v9, :cond_53

    .line 82
    .line 83
    goto :goto_68

    .line 84
    :cond_53
    iget v9, v6, Landroidx/constraintlayout/core/widgets/Barrier;->mBarrierType:I

    .line 85
    .line 86
    if-eqz v9, :cond_64

    .line 87
    .line 88
    if-ne v9, v5, :cond_5a

    .line 89
    .line 90
    goto :goto_64

    .line 91
    :cond_5a
    if-eq v9, v3, :cond_5f

    .line 92
    .line 93
    const/4 v10, 0x3

    .line 94
    if-ne v9, v10, :cond_68

    .line 95
    .line 96
    :cond_5f
    iget-object v8, v8, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mIsInBarrier:[Z

    .line 97
    .line 98
    aput-boolean v5, v8, v5

    .line 99
    .line 100
    goto :goto_68

    .line 101
    :cond_64
    :goto_64
    iget-object v8, v8, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mIsInBarrier:[Z

    .line 102
    .line 103
    aput-boolean v5, v8, v2

    .line 104
    .line 105
    :cond_68
    :goto_68
    add-int/lit8 v7, v7, 0x1

    .line 106
    .line 107
    goto :goto_40

    .line 108
    :cond_6b
    add-int/lit8 v4, v4, 0x1

    .line 109
    .line 110
    goto :goto_2f

    .line 111
    :cond_6e
    iget-object v4, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->widgetsToAdd:Ljava/util/HashSet;

    .line 112
    .line 113
    invoke-virtual {v4}, Ljava/util/HashSet;->clear()V

    .line 114
    .line 115
    .line 116
    const/4 v6, 0x0

    .line 117
    :goto_74
    if-ge v6, v1, :cond_9d

    .line 118
    .line 119
    iget-object v7, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 120
    .line 121
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v7

    .line 125
    check-cast v7, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 126
    .line 127
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    instance-of v8, v7, Landroidx/constraintlayout/core/widgets/VirtualLayout;

    .line 131
    .line 132
    if-nez v8, :cond_8c

    .line 133
    .line 134
    instance-of v8, v7, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 135
    .line 136
    if-eqz v8, :cond_8a

    .line 137
    .line 138
    goto :goto_8c

    .line 139
    :cond_8a
    const/4 v8, 0x0

    .line 140
    goto :goto_8d

    .line 141
    :cond_8c
    :goto_8c
    const/4 v8, 0x1

    .line 142
    :goto_8d
    if-eqz v8, :cond_9a

    .line 143
    .line 144
    instance-of v8, v7, Landroidx/constraintlayout/core/widgets/VirtualLayout;

    .line 145
    .line 146
    if-eqz v8, :cond_97

    .line 147
    .line 148
    invoke-virtual {v4, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    goto :goto_9a

    .line 152
    :cond_97
    invoke-virtual {v7, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 153
    .line 154
    .line 155
    :cond_9a
    :goto_9a
    add-int/lit8 v6, v6, 0x1

    .line 156
    .line 157
    goto :goto_74

    .line 158
    :cond_9d
    :goto_9d
    invoke-virtual {v4}, Ljava/util/HashSet;->size()I

    .line 159
    .line 160
    .line 161
    move-result v6

    .line 162
    if-lez v6, :cond_f4

    .line 163
    .line 164
    invoke-virtual {v4}, Ljava/util/HashSet;->size()I

    .line 165
    .line 166
    .line 167
    move-result v6

    .line 168
    invoke-virtual {v4}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 169
    .line 170
    .line 171
    move-result-object v7

    .line 172
    :cond_ab
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 173
    .line 174
    .line 175
    move-result v8

    .line 176
    if-eqz v8, :cond_d6

    .line 177
    .line 178
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v8

    .line 182
    check-cast v8, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 183
    .line 184
    check-cast v8, Landroidx/constraintlayout/core/widgets/VirtualLayout;

    .line 185
    .line 186
    const/4 v9, 0x0

    .line 187
    :goto_ba
    iget v10, v8, Landroidx/constraintlayout/core/widgets/HelperWidget;->mWidgetsCount:I

    .line 188
    .line 189
    if-ge v9, v10, :cond_cd

    .line 190
    .line 191
    iget-object v10, v8, Landroidx/constraintlayout/core/widgets/HelperWidget;->mWidgets:[Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 192
    .line 193
    aget-object v10, v10, v9

    .line 194
    .line 195
    invoke-virtual {v4, v10}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    move-result v10

    .line 199
    if-eqz v10, :cond_ca

    .line 200
    .line 201
    const/4 v9, 0x1

    .line 202
    goto :goto_ce

    .line 203
    :cond_ca
    add-int/lit8 v9, v9, 0x1

    .line 204
    .line 205
    goto :goto_ba

    .line 206
    :cond_cd
    const/4 v9, 0x0

    .line 207
    :goto_ce
    if-eqz v9, :cond_ab

    .line 208
    .line 209
    invoke-virtual {v8, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v4, v8}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    :cond_d6
    invoke-virtual {v4}, Ljava/util/HashSet;->size()I

    .line 216
    .line 217
    .line 218
    move-result v7

    .line 219
    if-ne v6, v7, :cond_9d

    .line 220
    .line 221
    invoke-virtual {v4}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 222
    .line 223
    .line 224
    move-result-object v6

    .line 225
    :goto_e0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 226
    .line 227
    .line 228
    move-result v7

    .line 229
    if-eqz v7, :cond_f0

    .line 230
    .line 231
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v7

    .line 235
    check-cast v7, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 236
    .line 237
    invoke-virtual {v7, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 238
    .line 239
    .line 240
    goto :goto_e0

    .line 241
    :cond_f0
    invoke-virtual {v4}, Ljava/util/HashSet;->clear()V

    .line 242
    .line 243
    .line 244
    goto :goto_9d

    .line 245
    :cond_f4
    sget-boolean v4, Landroidx/constraintlayout/core/LinearSystem;->USE_DEPENDENCY_ORDERING:Z

    .line 246
    .line 247
    if-eqz v4, :cond_147

    .line 248
    .line 249
    new-instance v4, Ljava/util/HashSet;

    .line 250
    .line 251
    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    .line 252
    .line 253
    .line 254
    const/4 v6, 0x0

    .line 255
    :goto_fe
    if-ge v6, v1, :cond_11f

    .line 256
    .line 257
    iget-object v7, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 258
    .line 259
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v7

    .line 263
    check-cast v7, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 264
    .line 265
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 266
    .line 267
    .line 268
    instance-of v8, v7, Landroidx/constraintlayout/core/widgets/VirtualLayout;

    .line 269
    .line 270
    if-nez v8, :cond_116

    .line 271
    .line 272
    instance-of v8, v7, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 273
    .line 274
    if-eqz v8, :cond_114

    .line 275
    .line 276
    goto :goto_116

    .line 277
    :cond_114
    const/4 v8, 0x0

    .line 278
    goto :goto_117

    .line 279
    :cond_116
    :goto_116
    const/4 v8, 0x1

    .line 280
    :goto_117
    if-nez v8, :cond_11c

    .line 281
    .line 282
    invoke-virtual {v4, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    :cond_11c
    add-int/lit8 v6, v6, 0x1

    .line 286
    .line 287
    goto :goto_fe

    .line 288
    :cond_11f
    iget-object v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 289
    .line 290
    aget v1, v1, v2

    .line 291
    .line 292
    if-ne v1, v3, :cond_127

    .line 293
    .line 294
    const/4 v10, 0x0

    .line 295
    goto :goto_128

    .line 296
    :cond_127
    const/4 v10, 0x1

    .line 297
    :goto_128
    const/4 v11, 0x0

    .line 298
    move-object v6, p0

    .line 299
    move-object v7, p0

    .line 300
    move-object v8, p1

    .line 301
    move-object v9, v4

    .line 302
    invoke-virtual/range {v6 .. v11}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addChildrenToSolverByDependency(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/LinearSystem;Ljava/util/HashSet;IZ)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v4}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 306
    .line 307
    .line 308
    move-result-object v1

    .line 309
    :goto_134
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 310
    .line 311
    .line 312
    move-result v3

    .line 313
    if-eqz v3, :cond_18b

    .line 314
    .line 315
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 320
    .line 321
    invoke-static {p0, p1, v3}, Landroidx/constraintlayout/core/widgets/Optimizer;->checkMatchParent(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/LinearSystem;Landroidx/constraintlayout/core/widgets/ConstraintWidget;)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {v3, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 325
    .line 326
    .line 327
    goto :goto_134

    .line 328
    :cond_147
    const/4 v4, 0x0

    .line 329
    :goto_148
    if-ge v4, v1, :cond_18b

    .line 330
    .line 331
    iget-object v6, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 332
    .line 333
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 334
    .line 335
    .line 336
    move-result-object v6

    .line 337
    check-cast v6, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 338
    .line 339
    instance-of v7, v6, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;

    .line 340
    .line 341
    if-eqz v7, :cond_174

    .line 342
    .line 343
    iget-object v7, v6, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 344
    .line 345
    aget v8, v7, v2

    .line 346
    .line 347
    aget v7, v7, v5

    .line 348
    .line 349
    if-ne v8, v3, :cond_161

    .line 350
    .line 351
    invoke-virtual {v6, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHorizontalDimensionBehaviour$enumunboxing$(I)V

    .line 352
    .line 353
    .line 354
    :cond_161
    if-ne v7, v3, :cond_166

    .line 355
    .line 356
    invoke-virtual {v6, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setVerticalDimensionBehaviour$enumunboxing$(I)V

    .line 357
    .line 358
    .line 359
    :cond_166
    invoke-virtual {v6, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 360
    .line 361
    .line 362
    if-ne v8, v3, :cond_16e

    .line 363
    .line 364
    invoke-virtual {v6, v8}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHorizontalDimensionBehaviour$enumunboxing$(I)V

    .line 365
    .line 366
    .line 367
    :cond_16e
    if-ne v7, v3, :cond_188

    .line 368
    .line 369
    invoke-virtual {v6, v7}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setVerticalDimensionBehaviour$enumunboxing$(I)V

    .line 370
    .line 371
    .line 372
    goto :goto_188

    .line 373
    :cond_174
    invoke-static {p0, p1, v6}, Landroidx/constraintlayout/core/widgets/Optimizer;->checkMatchParent(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/LinearSystem;Landroidx/constraintlayout/core/widgets/ConstraintWidget;)V

    .line 374
    .line 375
    .line 376
    instance-of v7, v6, Landroidx/constraintlayout/core/widgets/VirtualLayout;

    .line 377
    .line 378
    if-nez v7, :cond_182

    .line 379
    .line 380
    instance-of v7, v6, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 381
    .line 382
    if-eqz v7, :cond_180

    .line 383
    .line 384
    goto :goto_182

    .line 385
    :cond_180
    const/4 v7, 0x0

    .line 386
    goto :goto_183

    .line 387
    :cond_182
    :goto_182
    const/4 v7, 0x1

    .line 388
    :goto_183
    if-nez v7, :cond_188

    .line 389
    .line 390
    invoke-virtual {v6, p1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->addToSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 391
    .line 392
    .line 393
    :cond_188
    :goto_188
    add-int/lit8 v4, v4, 0x1

    .line 394
    .line 395
    goto :goto_148

    .line 396
    :cond_18b
    iget v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 397
    .line 398
    const/4 v1, 0x0

    .line 399
    if-lez v0, :cond_193

    .line 400
    .line 401
    invoke-static {p0, p1, v1, v2}, Landroidx/constraintlayout/core/widgets/Chain;->applyChainConstraints(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/LinearSystem;Ljava/util/ArrayList;I)V

    .line 402
    .line 403
    .line 404
    :cond_193
    iget v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 405
    .line 406
    if-lez v0, :cond_19a

    .line 407
    .line 408
    invoke-static {p0, p1, v1, v5}, Landroidx/constraintlayout/core/widgets/Chain;->applyChainConstraints(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/LinearSystem;Ljava/util/ArrayList;I)V

    .line 409
    .line 410
    .line 411
    :cond_19a
    return-void
.end method

.method public final directMeasureWithOrientation(IZ)Z
    .registers 16

    .line 1
    const/4 v0, 0x1

    .line 2
    and-int/2addr p2, v0

    .line 3
    iget-object v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mDependencyGraph:Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;

    .line 4
    .line 5
    iget-object v2, v1, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;->container:Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-virtual {v2, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getDimensionBehaviour$enumunboxing$(I)I

    .line 9
    .line 10
    .line 11
    move-result v4

    .line 12
    invoke-virtual {v2, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getDimensionBehaviour$enumunboxing$(I)I

    .line 13
    .line 14
    .line 15
    move-result v5

    .line 16
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getX()I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getY()I

    .line 21
    .line 22
    .line 23
    move-result v7

    .line 24
    iget-object v8, v1, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;->mRuns:Ljava/util/ArrayList;

    .line 25
    .line 26
    if-eqz p2, :cond_70

    .line 27
    .line 28
    const/4 v9, 0x2

    .line 29
    if-eq v4, v9, :cond_20

    .line 30
    .line 31
    if-ne v5, v9, :cond_70

    .line 32
    .line 33
    :cond_20
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object v10

    .line 37
    :cond_24
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v11

    .line 41
    if-eqz v11, :cond_3b

    .line 42
    .line 43
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v11

    .line 47
    check-cast v11, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;

    .line 48
    .line 49
    iget v12, v11, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->orientation:I

    .line 50
    .line 51
    if-ne v12, p1, :cond_24

    .line 52
    .line 53
    invoke-virtual {v11}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->supportsWrapComputation()Z

    .line 54
    .line 55
    .line 56
    move-result v11

    .line 57
    if-nez v11, :cond_24

    .line 58
    .line 59
    const/4 p2, 0x0

    .line 60
    :cond_3b
    if-nez p1, :cond_57

    .line 61
    .line 62
    if-eqz p2, :cond_70

    .line 63
    .line 64
    if-ne v4, v9, :cond_70

    .line 65
    .line 66
    invoke-virtual {v2, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHorizontalDimensionBehaviour$enumunboxing$(I)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v1, v2, v3}, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;->computeWrap(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;I)I

    .line 70
    .line 71
    .line 72
    move-result p2

    .line 73
    invoke-virtual {v2, p2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 74
    .line 75
    .line 76
    iget-object p2, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->horizontalRun:Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;

    .line 77
    .line 78
    iget-object p2, p2, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->dimension:Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;

    .line 79
    .line 80
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 81
    .line 82
    .line 83
    move-result v9

    .line 84
    invoke-virtual {p2, v9}, Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;->resolve(I)V

    .line 85
    .line 86
    .line 87
    goto :goto_70

    .line 88
    :cond_57
    if-eqz p2, :cond_70

    .line 89
    .line 90
    if-ne v5, v9, :cond_70

    .line 91
    .line 92
    invoke-virtual {v2, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setVerticalDimensionBehaviour$enumunboxing$(I)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1, v2, v0}, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;->computeWrap(Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;I)I

    .line 96
    .line 97
    .line 98
    move-result p2

    .line 99
    invoke-virtual {v2, p2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 100
    .line 101
    .line 102
    iget-object p2, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->verticalRun:Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;

    .line 103
    .line 104
    iget-object p2, p2, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->dimension:Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;

    .line 105
    .line 106
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 107
    .line 108
    .line 109
    move-result v9

    .line 110
    invoke-virtual {p2, v9}, Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;->resolve(I)V

    .line 111
    .line 112
    .line 113
    :cond_70
    :goto_70
    const/4 p2, 0x4

    .line 114
    iget-object v9, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 115
    .line 116
    if-nez p1, :cond_90

    .line 117
    .line 118
    aget v7, v9, v3

    .line 119
    .line 120
    if-eq v7, v0, :cond_7b

    .line 121
    .line 122
    if-ne v7, p2, :cond_97

    .line 123
    .line 124
    :cond_7b
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 125
    .line 126
    .line 127
    move-result p2

    .line 128
    add-int/2addr p2, v6

    .line 129
    iget-object v7, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->horizontalRun:Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;

    .line 130
    .line 131
    iget-object v7, v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->end:Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;

    .line 132
    .line 133
    invoke-virtual {v7, p2}, Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;->resolve(I)V

    .line 134
    .line 135
    .line 136
    iget-object v7, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->horizontalRun:Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;

    .line 137
    .line 138
    iget-object v7, v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->dimension:Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;

    .line 139
    .line 140
    sub-int/2addr p2, v6

    .line 141
    invoke-virtual {v7, p2}, Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;->resolve(I)V

    .line 142
    .line 143
    .line 144
    goto :goto_ad

    .line 145
    :cond_90
    aget v6, v9, v0

    .line 146
    .line 147
    if-eq v6, v0, :cond_99

    .line 148
    .line 149
    if-ne v6, p2, :cond_97

    .line 150
    .line 151
    goto :goto_99

    .line 152
    :cond_97
    const/4 p2, 0x0

    .line 153
    goto :goto_ae

    .line 154
    :cond_99
    :goto_99
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 155
    .line 156
    .line 157
    move-result p2

    .line 158
    add-int/2addr p2, v7

    .line 159
    iget-object v6, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->verticalRun:Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;

    .line 160
    .line 161
    iget-object v6, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->end:Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;

    .line 162
    .line 163
    invoke-virtual {v6, p2}, Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;->resolve(I)V

    .line 164
    .line 165
    .line 166
    iget-object v6, v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->verticalRun:Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;

    .line 167
    .line 168
    iget-object v6, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->dimension:Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;

    .line 169
    .line 170
    sub-int/2addr p2, v7

    .line 171
    invoke-virtual {v6, p2}, Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;->resolve(I)V

    .line 172
    .line 173
    .line 174
    :goto_ad
    const/4 p2, 0x1

    .line 175
    :goto_ae
    invoke-virtual {v1}, Landroidx/constraintlayout/core/widgets/analyzer/DependencyGraph;->measureWidgets()V

    .line 176
    .line 177
    .line 178
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    :goto_b5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 183
    .line 184
    .line 185
    move-result v6

    .line 186
    if-eqz v6, :cond_d3

    .line 187
    .line 188
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v6

    .line 192
    check-cast v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;

    .line 193
    .line 194
    iget v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->orientation:I

    .line 195
    .line 196
    if-eq v7, p1, :cond_c6

    .line 197
    .line 198
    goto :goto_b5

    .line 199
    :cond_c6
    iget-object v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->widget:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 200
    .line 201
    if-ne v7, v2, :cond_cf

    .line 202
    .line 203
    iget-boolean v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->resolved:Z

    .line 204
    .line 205
    if-nez v7, :cond_cf

    .line 206
    .line 207
    goto :goto_b5

    .line 208
    :cond_cf
    invoke-virtual {v6}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->applyToWidget()V

    .line 209
    .line 210
    .line 211
    goto :goto_b5

    .line 212
    :cond_d3
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    :cond_d7
    :goto_d7
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 217
    .line 218
    .line 219
    move-result v6

    .line 220
    if-eqz v6, :cond_108

    .line 221
    .line 222
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    move-result-object v6

    .line 226
    check-cast v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;

    .line 227
    .line 228
    iget v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->orientation:I

    .line 229
    .line 230
    if-eq v7, p1, :cond_e8

    .line 231
    .line 232
    goto :goto_d7

    .line 233
    :cond_e8
    if-nez p2, :cond_ef

    .line 234
    .line 235
    iget-object v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->widget:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 236
    .line 237
    if-ne v7, v2, :cond_ef

    .line 238
    .line 239
    goto :goto_d7

    .line 240
    :cond_ef
    iget-object v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->start:Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;

    .line 241
    .line 242
    iget-boolean v7, v7, Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;->resolved:Z

    .line 243
    .line 244
    if-nez v7, :cond_f6

    .line 245
    .line 246
    goto :goto_107

    .line 247
    :cond_f6
    iget-object v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->end:Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;

    .line 248
    .line 249
    iget-boolean v7, v7, Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;->resolved:Z

    .line 250
    .line 251
    if-nez v7, :cond_fd

    .line 252
    .line 253
    goto :goto_107

    .line 254
    :cond_fd
    instance-of v7, v6, Landroidx/constraintlayout/core/widgets/analyzer/ChainRun;

    .line 255
    .line 256
    if-nez v7, :cond_d7

    .line 257
    .line 258
    iget-object v6, v6, Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;->dimension:Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;

    .line 259
    .line 260
    iget-boolean v6, v6, Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;->resolved:Z

    .line 261
    .line 262
    if-nez v6, :cond_d7

    .line 263
    .line 264
    :goto_107
    const/4 v0, 0x0

    .line 265
    :cond_108
    invoke-virtual {v2, v4}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHorizontalDimensionBehaviour$enumunboxing$(I)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {v2, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setVerticalDimensionBehaviour$enumunboxing$(I)V

    .line 269
    .line 270
    .line 271
    return v0
.end method

.method public final getSceneString(Ljava/lang/StringBuilder;)V
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->stringId:Ljava/lang/String;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, ":{\n"

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    new-instance v0, Ljava/lang/StringBuilder;

    .line 24
    .line 25
    const-string v1, "  actualWidth:"

    .line 26
    .line 27
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    iget v1, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mWidth:I

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    const-string v0, "\n"

    .line 43
    .line 44
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    new-instance v1, Ljava/lang/StringBuilder;

    .line 48
    .line 49
    const-string v2, "  actualHeight:"

    .line 50
    .line 51
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    iget v2, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mHeight:I

    .line 55
    .line 56
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    iget-object v0, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 70
    .line 71
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    :goto_4a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    if-eqz v1, :cond_5f

    .line 80
    .line 81
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    check-cast v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 86
    .line 87
    invoke-virtual {v1, p1}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getSceneString(Ljava/lang/StringBuilder;)V

    .line 88
    .line 89
    .line 90
    const-string v1, ",\n"

    .line 91
    .line 92
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    goto :goto_4a

    .line 96
    :cond_5f
    const-string v0, "}"

    .line 97
    .line 98
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    return-void
.end method

.method public final layout()V
    .registers 31

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    iput v2, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mX:I

    .line 5
    .line 6
    iput v2, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mY:I

    .line 7
    .line 8
    iput-boolean v2, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mWidthMeasuredTooSmall:Z

    .line 9
    .line 10
    iput-boolean v2, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHeightMeasuredTooSmall:Z

    .line 11
    .line 12
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    iget-object v5, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 35
    .line 36
    const/4 v6, 0x1

    .line 37
    aget v7, v5, v6

    .line 38
    .line 39
    aget v8, v5, v2

    .line 40
    .line 41
    iget v9, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->pass:I

    .line 42
    .line 43
    iget-object v12, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mTop:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 44
    .line 45
    iget-object v13, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mLeft:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 46
    .line 47
    if-nez v9, :cond_258

    .line 48
    .line 49
    iget v9, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mOptimizationLevel:I

    .line 50
    .line 51
    invoke-static {v9, v6}, Landroidx/constraintlayout/core/widgets/Optimizer;->enabled(II)Z

    .line 52
    .line 53
    .line 54
    move-result v9

    .line 55
    if-eqz v9, :cond_258

    .line 56
    .line 57
    iget-object v9, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mMeasurer:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;

    .line 58
    .line 59
    aget v14, v5, v2

    .line 60
    .line 61
    aget v15, v5, v6

    .line 62
    .line 63
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->resetFinalResolution()V

    .line 64
    .line 65
    .line 66
    iget-object v11, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 67
    .line 68
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 69
    .line 70
    .line 71
    move-result v10

    .line 72
    :goto_47
    if-ge v2, v10, :cond_55

    .line 73
    .line 74
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v17

    .line 78
    check-cast v17, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 79
    .line 80
    invoke-virtual/range {v17 .. v17}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->resetFinalResolution()V

    .line 81
    .line 82
    .line 83
    add-int/lit8 v2, v2, 0x1

    .line 84
    .line 85
    goto :goto_47

    .line 86
    :cond_55
    iget-boolean v2, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mIsRtl:Z

    .line 87
    .line 88
    if-ne v14, v6, :cond_62

    .line 89
    .line 90
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 91
    .line 92
    .line 93
    move-result v14

    .line 94
    const/4 v6, 0x0

    .line 95
    invoke-virtual {v1, v6, v14}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setFinalHorizontal(II)V

    .line 96
    .line 97
    .line 98
    goto :goto_68

    .line 99
    :cond_62
    const/4 v6, 0x0

    .line 100
    invoke-virtual {v13, v6}, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->setFinalValue(I)V

    .line 101
    .line 102
    .line 103
    iput v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mX:I

    .line 104
    .line 105
    :goto_68
    const/4 v6, 0x0

    .line 106
    const/4 v14, 0x0

    .line 107
    const/16 v18, 0x0

    .line 108
    .line 109
    :goto_6c
    const/high16 v19, 0x3f000000    # 0.5f

    .line 110
    .line 111
    if-ge v6, v10, :cond_d7

    .line 112
    .line 113
    invoke-virtual {v11, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v20

    .line 117
    move-object/from16 v21, v13

    .line 118
    .line 119
    move-object/from16 v13, v20

    .line 120
    .line 121
    check-cast v13, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 122
    .line 123
    move/from16 v20, v4

    .line 124
    .line 125
    instance-of v4, v13, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 126
    .line 127
    if-eqz v4, :cond_be

    .line 128
    .line 129
    check-cast v13, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 130
    .line 131
    iget v4, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 132
    .line 133
    move-object/from16 v22, v5

    .line 134
    .line 135
    const/4 v5, 0x1

    .line 136
    if-ne v4, v5, :cond_ce

    .line 137
    .line 138
    iget v4, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativeBegin:I

    .line 139
    .line 140
    const/4 v5, -0x1

    .line 141
    if-eq v4, v5, :cond_92

    .line 142
    .line 143
    invoke-virtual {v13, v4}, Landroidx/constraintlayout/core/widgets/Guideline;->setFinalValue(I)V

    .line 144
    .line 145
    .line 146
    goto :goto_bc

    .line 147
    :cond_92
    iget v4, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativeEnd:I

    .line 148
    .line 149
    if-eq v4, v5, :cond_a7

    .line 150
    .line 151
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isResolvedHorizontally()Z

    .line 152
    .line 153
    .line 154
    move-result v4

    .line 155
    if-eqz v4, :cond_a7

    .line 156
    .line 157
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 158
    .line 159
    .line 160
    move-result v4

    .line 161
    iget v5, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativeEnd:I

    .line 162
    .line 163
    sub-int/2addr v4, v5

    .line 164
    invoke-virtual {v13, v4}, Landroidx/constraintlayout/core/widgets/Guideline;->setFinalValue(I)V

    .line 165
    .line 166
    .line 167
    goto :goto_bc

    .line 168
    :cond_a7
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isResolvedHorizontally()Z

    .line 169
    .line 170
    .line 171
    move-result v4

    .line 172
    if-eqz v4, :cond_bc

    .line 173
    .line 174
    iget v4, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativePercent:F

    .line 175
    .line 176
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 177
    .line 178
    .line 179
    move-result v5

    .line 180
    int-to-float v5, v5

    .line 181
    mul-float v4, v4, v5

    .line 182
    .line 183
    add-float v4, v4, v19

    .line 184
    .line 185
    float-to-int v4, v4

    .line 186
    invoke-virtual {v13, v4}, Landroidx/constraintlayout/core/widgets/Guideline;->setFinalValue(I)V

    .line 187
    .line 188
    .line 189
    :cond_bc
    :goto_bc
    const/4 v14, 0x1

    .line 190
    goto :goto_ce

    .line 191
    :cond_be
    move-object/from16 v22, v5

    .line 192
    .line 193
    instance-of v4, v13, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 194
    .line 195
    if-eqz v4, :cond_ce

    .line 196
    .line 197
    check-cast v13, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 198
    .line 199
    invoke-virtual {v13}, Landroidx/constraintlayout/core/widgets/Barrier;->getOrientation()I

    .line 200
    .line 201
    .line 202
    move-result v4

    .line 203
    if-nez v4, :cond_ce

    .line 204
    .line 205
    const/16 v18, 0x1

    .line 206
    .line 207
    :cond_ce
    :goto_ce
    add-int/lit8 v6, v6, 0x1

    .line 208
    .line 209
    move/from16 v4, v20

    .line 210
    .line 211
    move-object/from16 v13, v21

    .line 212
    .line 213
    move-object/from16 v5, v22

    .line 214
    .line 215
    goto :goto_6c

    .line 216
    :cond_d7
    move/from16 v20, v4

    .line 217
    .line 218
    move-object/from16 v22, v5

    .line 219
    .line 220
    move-object/from16 v21, v13

    .line 221
    .line 222
    if-eqz v14, :cond_fc

    .line 223
    .line 224
    const/4 v4, 0x0

    .line 225
    :goto_e0
    if-ge v4, v10, :cond_fc

    .line 226
    .line 227
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v5

    .line 231
    check-cast v5, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 232
    .line 233
    instance-of v6, v5, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 234
    .line 235
    if-eqz v6, :cond_f8

    .line 236
    .line 237
    check-cast v5, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 238
    .line 239
    iget v6, v5, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 240
    .line 241
    const/4 v13, 0x1

    .line 242
    if-ne v6, v13, :cond_f8

    .line 243
    .line 244
    const/4 v6, 0x0

    .line 245
    invoke-static {v6, v5, v9, v2}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->horizontalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Z)V

    .line 246
    .line 247
    .line 248
    goto :goto_f9

    .line 249
    :cond_f8
    const/4 v6, 0x0

    .line 250
    :goto_f9
    add-int/lit8 v4, v4, 0x1

    .line 251
    .line 252
    goto :goto_e0

    .line 253
    :cond_fc
    const/4 v6, 0x0

    .line 254
    invoke-static {v6, v1, v9, v2}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->horizontalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Z)V

    .line 255
    .line 256
    .line 257
    if-eqz v18, :cond_124

    .line 258
    .line 259
    const/4 v4, 0x0

    .line 260
    :goto_103
    if-ge v4, v10, :cond_124

    .line 261
    .line 262
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v5

    .line 266
    check-cast v5, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 267
    .line 268
    instance-of v6, v5, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 269
    .line 270
    if-eqz v6, :cond_121

    .line 271
    .line 272
    check-cast v5, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 273
    .line 274
    invoke-virtual {v5}, Landroidx/constraintlayout/core/widgets/Barrier;->getOrientation()I

    .line 275
    .line 276
    .line 277
    move-result v6

    .line 278
    if-nez v6, :cond_121

    .line 279
    .line 280
    invoke-virtual {v5}, Landroidx/constraintlayout/core/widgets/Barrier;->allSolved()Z

    .line 281
    .line 282
    .line 283
    move-result v6

    .line 284
    if-eqz v6, :cond_121

    .line 285
    .line 286
    const/4 v6, 0x1

    .line 287
    invoke-static {v6, v5, v9, v2}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->horizontalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Z)V

    .line 288
    .line 289
    .line 290
    :cond_121
    add-int/lit8 v4, v4, 0x1

    .line 291
    .line 292
    goto :goto_103

    .line 293
    :cond_124
    const/4 v4, 0x1

    .line 294
    if-ne v15, v4, :cond_130

    .line 295
    .line 296
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 297
    .line 298
    .line 299
    move-result v4

    .line 300
    const/4 v5, 0x0

    .line 301
    invoke-virtual {v1, v5, v4}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setFinalVertical(II)V

    .line 302
    .line 303
    .line 304
    goto :goto_136

    .line 305
    :cond_130
    const/4 v5, 0x0

    .line 306
    invoke-virtual {v12, v5}, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->setFinalValue(I)V

    .line 307
    .line 308
    .line 309
    iput v5, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mY:I

    .line 310
    .line 311
    :goto_136
    const/4 v4, 0x0

    .line 312
    const/4 v5, 0x0

    .line 313
    const/4 v6, 0x0

    .line 314
    :goto_139
    if-ge v4, v10, :cond_191

    .line 315
    .line 316
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object v13

    .line 320
    check-cast v13, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 321
    .line 322
    instance-of v14, v13, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 323
    .line 324
    if-eqz v14, :cond_180

    .line 325
    .line 326
    check-cast v13, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 327
    .line 328
    iget v14, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 329
    .line 330
    if-nez v14, :cond_18e

    .line 331
    .line 332
    iget v5, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativeBegin:I

    .line 333
    .line 334
    const/4 v14, -0x1

    .line 335
    if-eq v5, v14, :cond_154

    .line 336
    .line 337
    invoke-virtual {v13, v5}, Landroidx/constraintlayout/core/widgets/Guideline;->setFinalValue(I)V

    .line 338
    .line 339
    .line 340
    goto :goto_17e

    .line 341
    :cond_154
    iget v5, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativeEnd:I

    .line 342
    .line 343
    if-eq v5, v14, :cond_169

    .line 344
    .line 345
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isResolvedVertically()Z

    .line 346
    .line 347
    .line 348
    move-result v5

    .line 349
    if-eqz v5, :cond_169

    .line 350
    .line 351
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 352
    .line 353
    .line 354
    move-result v5

    .line 355
    iget v14, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativeEnd:I

    .line 356
    .line 357
    sub-int/2addr v5, v14

    .line 358
    invoke-virtual {v13, v5}, Landroidx/constraintlayout/core/widgets/Guideline;->setFinalValue(I)V

    .line 359
    .line 360
    .line 361
    goto :goto_17e

    .line 362
    :cond_169
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isResolvedVertically()Z

    .line 363
    .line 364
    .line 365
    move-result v5

    .line 366
    if-eqz v5, :cond_17e

    .line 367
    .line 368
    iget v5, v13, Landroidx/constraintlayout/core/widgets/Guideline;->mRelativePercent:F

    .line 369
    .line 370
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 371
    .line 372
    .line 373
    move-result v14

    .line 374
    int-to-float v14, v14

    .line 375
    mul-float v5, v5, v14

    .line 376
    .line 377
    add-float v5, v5, v19

    .line 378
    .line 379
    float-to-int v5, v5

    .line 380
    invoke-virtual {v13, v5}, Landroidx/constraintlayout/core/widgets/Guideline;->setFinalValue(I)V

    .line 381
    .line 382
    .line 383
    :cond_17e
    :goto_17e
    const/4 v5, 0x1

    .line 384
    goto :goto_18e

    .line 385
    :cond_180
    instance-of v14, v13, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 386
    .line 387
    if-eqz v14, :cond_18e

    .line 388
    .line 389
    check-cast v13, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 390
    .line 391
    invoke-virtual {v13}, Landroidx/constraintlayout/core/widgets/Barrier;->getOrientation()I

    .line 392
    .line 393
    .line 394
    move-result v13

    .line 395
    const/4 v14, 0x1

    .line 396
    if-ne v13, v14, :cond_18e

    .line 397
    .line 398
    const/4 v6, 0x1

    .line 399
    :cond_18e
    :goto_18e
    add-int/lit8 v4, v4, 0x1

    .line 400
    .line 401
    goto :goto_139

    .line 402
    :cond_191
    if-eqz v5, :cond_1ad

    .line 403
    .line 404
    const/4 v4, 0x0

    .line 405
    :goto_194
    if-ge v4, v10, :cond_1ad

    .line 406
    .line 407
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object v5

    .line 411
    check-cast v5, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 412
    .line 413
    instance-of v13, v5, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 414
    .line 415
    if-eqz v13, :cond_1aa

    .line 416
    .line 417
    check-cast v5, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 418
    .line 419
    iget v13, v5, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 420
    .line 421
    if-nez v13, :cond_1aa

    .line 422
    .line 423
    const/4 v13, 0x1

    .line 424
    invoke-static {v13, v5, v9}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->verticalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V

    .line 425
    .line 426
    .line 427
    :cond_1aa
    add-int/lit8 v4, v4, 0x1

    .line 428
    .line 429
    goto :goto_194

    .line 430
    :cond_1ad
    const/4 v4, 0x0

    .line 431
    invoke-static {v4, v1, v9}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->verticalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V

    .line 432
    .line 433
    .line 434
    if-eqz v6, :cond_1d5

    .line 435
    .line 436
    const/4 v4, 0x0

    .line 437
    :goto_1b4
    if-ge v4, v10, :cond_1d5

    .line 438
    .line 439
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 440
    .line 441
    .line 442
    move-result-object v5

    .line 443
    check-cast v5, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 444
    .line 445
    instance-of v6, v5, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 446
    .line 447
    if-eqz v6, :cond_1d2

    .line 448
    .line 449
    check-cast v5, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 450
    .line 451
    invoke-virtual {v5}, Landroidx/constraintlayout/core/widgets/Barrier;->getOrientation()I

    .line 452
    .line 453
    .line 454
    move-result v6

    .line 455
    const/4 v13, 0x1

    .line 456
    if-ne v6, v13, :cond_1d2

    .line 457
    .line 458
    invoke-virtual {v5}, Landroidx/constraintlayout/core/widgets/Barrier;->allSolved()Z

    .line 459
    .line 460
    .line 461
    move-result v6

    .line 462
    if-eqz v6, :cond_1d2

    .line 463
    .line 464
    invoke-static {v13, v5, v9}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->verticalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V

    .line 465
    .line 466
    .line 467
    :cond_1d2
    add-int/lit8 v4, v4, 0x1

    .line 468
    .line 469
    goto :goto_1b4

    .line 470
    :cond_1d5
    const/4 v4, 0x0

    .line 471
    :goto_1d6
    if-ge v4, v10, :cond_20e

    .line 472
    .line 473
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 474
    .line 475
    .line 476
    move-result-object v5

    .line 477
    check-cast v5, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 478
    .line 479
    invoke-virtual {v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isMeasureRequested()Z

    .line 480
    .line 481
    .line 482
    move-result v6

    .line 483
    if-eqz v6, :cond_20b

    .line 484
    .line 485
    invoke-static {v5}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->canMeasure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;)Z

    .line 486
    .line 487
    .line 488
    move-result v6

    .line 489
    if-eqz v6, :cond_20b

    .line 490
    .line 491
    sget-object v6, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->measure:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;

    .line 492
    .line 493
    invoke-static {v5, v9, v6}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V

    .line 494
    .line 495
    .line 496
    instance-of v6, v5, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 497
    .line 498
    if-eqz v6, :cond_204

    .line 499
    .line 500
    move-object v6, v5

    .line 501
    check-cast v6, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 502
    .line 503
    iget v6, v6, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 504
    .line 505
    if-nez v6, :cond_1ff

    .line 506
    .line 507
    const/4 v6, 0x0

    .line 508
    invoke-static {v6, v5, v9}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->verticalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V

    .line 509
    .line 510
    .line 511
    goto :goto_20b

    .line 512
    :cond_1ff
    const/4 v6, 0x0

    .line 513
    invoke-static {v6, v5, v9, v2}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->horizontalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Z)V

    .line 514
    .line 515
    .line 516
    goto :goto_20b

    .line 517
    :cond_204
    const/4 v6, 0x0

    .line 518
    invoke-static {v6, v5, v9, v2}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->horizontalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Z)V

    .line 519
    .line 520
    .line 521
    invoke-static {v6, v5, v9}, Landroidx/constraintlayout/core/widgets/analyzer/Direct;->verticalSolvingPass(ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V

    .line 522
    .line 523
    .line 524
    :cond_20b
    :goto_20b
    add-int/lit8 v4, v4, 0x1

    .line 525
    .line 526
    goto :goto_1d6

    .line 527
    :cond_20e
    const/4 v2, 0x0

    .line 528
    :goto_20f
    if-ge v2, v3, :cond_25e

    .line 529
    .line 530
    iget-object v4, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 531
    .line 532
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 533
    .line 534
    .line 535
    move-result-object v4

    .line 536
    check-cast v4, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 537
    .line 538
    invoke-virtual {v4}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->isMeasureRequested()Z

    .line 539
    .line 540
    .line 541
    move-result v5

    .line 542
    if-eqz v5, :cond_255

    .line 543
    .line 544
    instance-of v5, v4, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 545
    .line 546
    if-nez v5, :cond_255

    .line 547
    .line 548
    instance-of v5, v4, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 549
    .line 550
    if-nez v5, :cond_255

    .line 551
    .line 552
    instance-of v5, v4, Landroidx/constraintlayout/core/widgets/VirtualLayout;

    .line 553
    .line 554
    if-nez v5, :cond_255

    .line 555
    .line 556
    iget-boolean v5, v4, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mInVirtualLayout:Z

    .line 557
    .line 558
    if-nez v5, :cond_255

    .line 559
    .line 560
    const/4 v5, 0x0

    .line 561
    invoke-virtual {v4, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getDimensionBehaviour$enumunboxing$(I)I

    .line 562
    .line 563
    .line 564
    move-result v6

    .line 565
    const/4 v5, 0x1

    .line 566
    invoke-virtual {v4, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getDimensionBehaviour$enumunboxing$(I)I

    .line 567
    .line 568
    .line 569
    move-result v9

    .line 570
    const/4 v10, 0x3

    .line 571
    if-ne v6, v10, :cond_248

    .line 572
    .line 573
    iget v6, v4, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMatchConstraintDefaultWidth:I

    .line 574
    .line 575
    if-eq v6, v5, :cond_248

    .line 576
    .line 577
    if-ne v9, v10, :cond_248

    .line 578
    .line 579
    iget v6, v4, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMatchConstraintDefaultHeight:I

    .line 580
    .line 581
    if-eq v6, v5, :cond_248

    .line 582
    .line 583
    const/4 v5, 0x1

    .line 584
    goto :goto_249

    .line 585
    :cond_248
    const/4 v5, 0x0

    .line 586
    :goto_249
    if-nez v5, :cond_255

    .line 587
    .line 588
    new-instance v5, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;

    .line 589
    .line 590
    invoke-direct {v5}, Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;-><init>()V

    .line 591
    .line 592
    .line 593
    iget-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mMeasurer:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;

    .line 594
    .line 595
    invoke-static {v4, v6, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V

    .line 596
    .line 597
    .line 598
    :cond_255
    add-int/lit8 v2, v2, 0x1

    .line 599
    .line 600
    goto :goto_20f

    .line 601
    :cond_258
    move/from16 v20, v4

    .line 602
    .line 603
    move-object/from16 v22, v5

    .line 604
    .line 605
    move-object/from16 v21, v13

    .line 606
    .line 607
    :cond_25e
    iget-object v2, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mSystem:Landroidx/constraintlayout/core/LinearSystem;

    .line 608
    .line 609
    const/4 v4, 0x2

    .line 610
    if-le v3, v4, :cond_659

    .line 611
    .line 612
    if-eq v8, v4, :cond_267

    .line 613
    .line 614
    if-ne v7, v4, :cond_659

    .line 615
    .line 616
    :cond_267
    iget v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mOptimizationLevel:I

    .line 617
    .line 618
    const/16 v9, 0x400

    .line 619
    .line 620
    invoke-static {v6, v9}, Landroidx/constraintlayout/core/widgets/Optimizer;->enabled(II)Z

    .line 621
    .line 622
    .line 623
    move-result v6

    .line 624
    if-eqz v6, :cond_659

    .line 625
    .line 626
    iget-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mMeasurer:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;

    .line 627
    .line 628
    iget-object v9, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 629
    .line 630
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 631
    .line 632
    .line 633
    move-result v10

    .line 634
    const/4 v11, 0x0

    .line 635
    :goto_27a
    if-ge v11, v10, :cond_2ae

    .line 636
    .line 637
    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 638
    .line 639
    .line 640
    move-result-object v13

    .line 641
    check-cast v13, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 642
    .line 643
    const/4 v14, 0x0

    .line 644
    aget v15, v22, v14

    .line 645
    .line 646
    const/16 v17, 0x1

    .line 647
    .line 648
    aget v4, v22, v17

    .line 649
    .line 650
    iget-object v5, v13, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 651
    .line 652
    move-object/from16 v23, v12

    .line 653
    .line 654
    aget v12, v5, v14

    .line 655
    .line 656
    aget v5, v5, v17

    .line 657
    .line 658
    invoke-static {v15, v4, v12, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->validInGroup(IIII)Z

    .line 659
    .line 660
    .line 661
    move-result v4

    .line 662
    if-nez v4, :cond_298

    .line 663
    .line 664
    goto :goto_29c

    .line 665
    :cond_298
    instance-of v4, v13, Landroidx/constraintlayout/core/widgets/Flow;

    .line 666
    .line 667
    if-eqz v4, :cond_2a8

    .line 668
    .line 669
    :goto_29c
    move/from16 v26, v0

    .line 670
    .line 671
    move/from16 v25, v3

    .line 672
    .line 673
    move/from16 v24, v7

    .line 674
    .line 675
    move/from16 v27, v8

    .line 676
    .line 677
    const/4 v0, 0x0

    .line 678
    move-object v8, v2

    .line 679
    goto/16 :goto_60e

    .line 680
    .line 681
    :cond_2a8
    add-int/lit8 v11, v11, 0x1

    .line 682
    .line 683
    move-object/from16 v12, v23

    .line 684
    .line 685
    const/4 v4, 0x2

    .line 686
    goto :goto_27a

    .line 687
    :cond_2ae
    move-object/from16 v23, v12

    .line 688
    .line 689
    const/4 v4, 0x0

    .line 690
    const/4 v5, 0x0

    .line 691
    const/4 v11, 0x0

    .line 692
    const/4 v12, 0x0

    .line 693
    const/4 v13, 0x0

    .line 694
    const/4 v14, 0x0

    .line 695
    const/4 v15, 0x0

    .line 696
    :goto_2b7
    if-ge v4, v10, :cond_39a

    .line 697
    .line 698
    invoke-virtual {v9, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 699
    .line 700
    .line 701
    move-result-object v24

    .line 702
    move/from16 v25, v3

    .line 703
    .line 704
    move-object/from16 v3, v24

    .line 705
    .line 706
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 707
    .line 708
    move/from16 v24, v7

    .line 709
    .line 710
    const/16 v16, 0x0

    .line 711
    .line 712
    aget v7, v22, v16

    .line 713
    .line 714
    move/from16 v26, v0

    .line 715
    .line 716
    const/16 v17, 0x1

    .line 717
    .line 718
    aget v0, v22, v17

    .line 719
    .line 720
    move/from16 v27, v8

    .line 721
    .line 722
    iget-object v8, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 723
    .line 724
    move-object/from16 v28, v2

    .line 725
    .line 726
    aget v2, v8, v16

    .line 727
    .line 728
    aget v8, v8, v17

    .line 729
    .line 730
    invoke-static {v7, v0, v2, v8}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->validInGroup(IIII)Z

    .line 731
    .line 732
    .line 733
    move-result v0

    .line 734
    if-nez v0, :cond_2e4

    .line 735
    .line 736
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mMeasure:Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;

    .line 737
    .line 738
    invoke-static {v3, v6, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->measure(Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;)V

    .line 739
    .line 740
    .line 741
    :cond_2e4
    instance-of v0, v3, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 742
    .line 743
    if-eqz v0, :cond_309

    .line 744
    .line 745
    move-object v2, v3

    .line 746
    check-cast v2, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 747
    .line 748
    iget v7, v2, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 749
    .line 750
    if-nez v7, :cond_2fa

    .line 751
    .line 752
    if-nez v12, :cond_2f7

    .line 753
    .line 754
    new-instance v7, Ljava/util/ArrayList;

    .line 755
    .line 756
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 757
    .line 758
    .line 759
    move-object v12, v7

    .line 760
    :cond_2f7
    invoke-virtual {v12, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 761
    .line 762
    .line 763
    :cond_2fa
    iget v7, v2, Landroidx/constraintlayout/core/widgets/Guideline;->mOrientation:I

    .line 764
    .line 765
    const/4 v8, 0x1

    .line 766
    if-ne v7, v8, :cond_309

    .line 767
    .line 768
    if-nez v5, :cond_306

    .line 769
    .line 770
    new-instance v5, Ljava/util/ArrayList;

    .line 771
    .line 772
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 773
    .line 774
    .line 775
    :cond_306
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 776
    .line 777
    .line 778
    :cond_309
    instance-of v2, v3, Landroidx/constraintlayout/core/widgets/HelperWidget;

    .line 779
    .line 780
    if-eqz v2, :cond_34e

    .line 781
    .line 782
    instance-of v2, v3, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 783
    .line 784
    if-eqz v2, :cond_337

    .line 785
    .line 786
    move-object v2, v3

    .line 787
    check-cast v2, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 788
    .line 789
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/Barrier;->getOrientation()I

    .line 790
    .line 791
    .line 792
    move-result v7

    .line 793
    if-nez v7, :cond_325

    .line 794
    .line 795
    if-nez v11, :cond_322

    .line 796
    .line 797
    new-instance v7, Ljava/util/ArrayList;

    .line 798
    .line 799
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 800
    .line 801
    .line 802
    move-object v11, v7

    .line 803
    :cond_322
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 804
    .line 805
    .line 806
    :cond_325
    invoke-virtual {v2}, Landroidx/constraintlayout/core/widgets/Barrier;->getOrientation()I

    .line 807
    .line 808
    .line 809
    move-result v7

    .line 810
    const/4 v8, 0x1

    .line 811
    if-ne v7, v8, :cond_34e

    .line 812
    .line 813
    if-nez v13, :cond_333

    .line 814
    .line 815
    new-instance v13, Ljava/util/ArrayList;

    .line 816
    .line 817
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 818
    .line 819
    .line 820
    :cond_333
    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 821
    .line 822
    .line 823
    goto :goto_34e

    .line 824
    :cond_337
    move-object v2, v3

    .line 825
    check-cast v2, Landroidx/constraintlayout/core/widgets/HelperWidget;

    .line 826
    .line 827
    if-nez v11, :cond_341

    .line 828
    .line 829
    new-instance v11, Ljava/util/ArrayList;

    .line 830
    .line 831
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 832
    .line 833
    .line 834
    :cond_341
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 835
    .line 836
    .line 837
    if-nez v13, :cond_34b

    .line 838
    .line 839
    new-instance v13, Ljava/util/ArrayList;

    .line 840
    .line 841
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 842
    .line 843
    .line 844
    :cond_34b
    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 845
    .line 846
    .line 847
    :cond_34e
    :goto_34e
    iget-object v2, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mLeft:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 848
    .line 849
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mTarget:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 850
    .line 851
    if-nez v2, :cond_36a

    .line 852
    .line 853
    iget-object v2, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mRight:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 854
    .line 855
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mTarget:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 856
    .line 857
    if-nez v2, :cond_36a

    .line 858
    .line 859
    if-nez v0, :cond_36a

    .line 860
    .line 861
    instance-of v2, v3, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 862
    .line 863
    if-nez v2, :cond_36a

    .line 864
    .line 865
    if-nez v14, :cond_367

    .line 866
    .line 867
    new-instance v14, Ljava/util/ArrayList;

    .line 868
    .line 869
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 870
    .line 871
    .line 872
    :cond_367
    invoke-virtual {v14, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 873
    .line 874
    .line 875
    :cond_36a
    iget-object v2, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mTop:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 876
    .line 877
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mTarget:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 878
    .line 879
    if-nez v2, :cond_38c

    .line 880
    .line 881
    iget-object v2, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mBottom:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 882
    .line 883
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mTarget:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 884
    .line 885
    if-nez v2, :cond_38c

    .line 886
    .line 887
    iget-object v2, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mBaseline:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 888
    .line 889
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mTarget:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 890
    .line 891
    if-nez v2, :cond_38c

    .line 892
    .line 893
    if-nez v0, :cond_38c

    .line 894
    .line 895
    instance-of v0, v3, Landroidx/constraintlayout/core/widgets/Barrier;

    .line 896
    .line 897
    if-nez v0, :cond_38c

    .line 898
    .line 899
    if-nez v15, :cond_389

    .line 900
    .line 901
    new-instance v15, Ljava/util/ArrayList;

    .line 902
    .line 903
    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    .line 904
    .line 905
    .line 906
    :cond_389
    invoke-virtual {v15, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 907
    .line 908
    .line 909
    :cond_38c
    add-int/lit8 v4, v4, 0x1

    .line 910
    .line 911
    move/from16 v7, v24

    .line 912
    .line 913
    move/from16 v3, v25

    .line 914
    .line 915
    move/from16 v0, v26

    .line 916
    .line 917
    move/from16 v8, v27

    .line 918
    .line 919
    move-object/from16 v2, v28

    .line 920
    .line 921
    goto/16 :goto_2b7

    .line 922
    .line 923
    :cond_39a
    move/from16 v26, v0

    .line 924
    .line 925
    move-object/from16 v28, v2

    .line 926
    .line 927
    move/from16 v25, v3

    .line 928
    .line 929
    move/from16 v24, v7

    .line 930
    .line 931
    move/from16 v27, v8

    .line 932
    .line 933
    new-instance v0, Ljava/util/ArrayList;

    .line 934
    .line 935
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 936
    .line 937
    .line 938
    if-eqz v5, :cond_3c1

    .line 939
    .line 940
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 941
    .line 942
    .line 943
    move-result-object v2

    .line 944
    :goto_3af
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 945
    .line 946
    .line 947
    move-result v3

    .line 948
    if-eqz v3, :cond_3c1

    .line 949
    .line 950
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 951
    .line 952
    .line 953
    move-result-object v3

    .line 954
    check-cast v3, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 955
    .line 956
    const/4 v4, 0x0

    .line 957
    const/4 v5, 0x0

    .line 958
    invoke-static {v3, v5, v0, v4}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 959
    .line 960
    .line 961
    goto :goto_3af

    .line 962
    :cond_3c1
    const/4 v4, 0x0

    .line 963
    const/4 v5, 0x0

    .line 964
    if-eqz v11, :cond_3e2

    .line 965
    .line 966
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 967
    .line 968
    .line 969
    move-result-object v2

    .line 970
    :goto_3c9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 971
    .line 972
    .line 973
    move-result v3

    .line 974
    if-eqz v3, :cond_3e2

    .line 975
    .line 976
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 977
    .line 978
    .line 979
    move-result-object v3

    .line 980
    check-cast v3, Landroidx/constraintlayout/core/widgets/HelperWidget;

    .line 981
    .line 982
    invoke-static {v3, v5, v0, v4}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 983
    .line 984
    .line 985
    move-result-object v6

    .line 986
    invoke-virtual {v3, v5, v6, v0}, Landroidx/constraintlayout/core/widgets/HelperWidget;->addDependents(ILandroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;Ljava/util/ArrayList;)V

    .line 987
    .line 988
    .line 989
    invoke-virtual {v6, v0}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->cleanup(Ljava/util/ArrayList;)V

    .line 990
    .line 991
    .line 992
    const/4 v4, 0x0

    .line 993
    const/4 v5, 0x0

    .line 994
    goto :goto_3c9

    .line 995
    :cond_3e2
    sget-object v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;->LEFT:Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;

    .line 996
    .line 997
    invoke-virtual {v1, v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 998
    .line 999
    .line 1000
    move-result-object v2

    .line 1001
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1002
    .line 1003
    if-eqz v2, :cond_404

    .line 1004
    .line 1005
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1006
    .line 1007
    .line 1008
    move-result-object v2

    .line 1009
    :goto_3f0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1010
    .line 1011
    .line 1012
    move-result v3

    .line 1013
    if-eqz v3, :cond_404

    .line 1014
    .line 1015
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1016
    .line 1017
    .line 1018
    move-result-object v3

    .line 1019
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1020
    .line 1021
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1022
    .line 1023
    const/4 v4, 0x0

    .line 1024
    const/4 v5, 0x0

    .line 1025
    invoke-static {v3, v5, v0, v4}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1026
    .line 1027
    .line 1028
    goto :goto_3f0

    .line 1029
    :cond_404
    sget-object v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;->RIGHT:Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;

    .line 1030
    .line 1031
    invoke-virtual {v1, v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1032
    .line 1033
    .line 1034
    move-result-object v2

    .line 1035
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1036
    .line 1037
    if-eqz v2, :cond_426

    .line 1038
    .line 1039
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1040
    .line 1041
    .line 1042
    move-result-object v2

    .line 1043
    :goto_412
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1044
    .line 1045
    .line 1046
    move-result v3

    .line 1047
    if-eqz v3, :cond_426

    .line 1048
    .line 1049
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v3

    .line 1053
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1054
    .line 1055
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1056
    .line 1057
    const/4 v4, 0x0

    .line 1058
    const/4 v5, 0x0

    .line 1059
    invoke-static {v3, v5, v0, v4}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1060
    .line 1061
    .line 1062
    goto :goto_412

    .line 1063
    :cond_426
    sget-object v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;->CENTER:Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;

    .line 1064
    .line 1065
    invoke-virtual {v1, v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1066
    .line 1067
    .line 1068
    move-result-object v3

    .line 1069
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1070
    .line 1071
    if-eqz v3, :cond_448

    .line 1072
    .line 1073
    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1074
    .line 1075
    .line 1076
    move-result-object v3

    .line 1077
    :goto_434
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1078
    .line 1079
    .line 1080
    move-result v4

    .line 1081
    if-eqz v4, :cond_448

    .line 1082
    .line 1083
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1084
    .line 1085
    .line 1086
    move-result-object v4

    .line 1087
    check-cast v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1088
    .line 1089
    iget-object v4, v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1090
    .line 1091
    const/4 v5, 0x0

    .line 1092
    const/4 v6, 0x0

    .line 1093
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1094
    .line 1095
    .line 1096
    goto :goto_434

    .line 1097
    :cond_448
    const/4 v5, 0x0

    .line 1098
    const/4 v6, 0x0

    .line 1099
    if-eqz v14, :cond_460

    .line 1100
    .line 1101
    invoke-virtual {v14}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1102
    .line 1103
    .line 1104
    move-result-object v3

    .line 1105
    :goto_450
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1106
    .line 1107
    .line 1108
    move-result v4

    .line 1109
    if-eqz v4, :cond_460

    .line 1110
    .line 1111
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1112
    .line 1113
    .line 1114
    move-result-object v4

    .line 1115
    check-cast v4, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1116
    .line 1117
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1118
    .line 1119
    .line 1120
    goto :goto_450

    .line 1121
    :cond_460
    if-eqz v12, :cond_477

    .line 1122
    .line 1123
    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1124
    .line 1125
    .line 1126
    move-result-object v3

    .line 1127
    :goto_466
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1128
    .line 1129
    .line 1130
    move-result v4

    .line 1131
    if-eqz v4, :cond_477

    .line 1132
    .line 1133
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1134
    .line 1135
    .line 1136
    move-result-object v4

    .line 1137
    check-cast v4, Landroidx/constraintlayout/core/widgets/Guideline;

    .line 1138
    .line 1139
    const/4 v6, 0x1

    .line 1140
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1141
    .line 1142
    .line 1143
    goto :goto_466

    .line 1144
    :cond_477
    const/4 v6, 0x1

    .line 1145
    if-eqz v13, :cond_497

    .line 1146
    .line 1147
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1148
    .line 1149
    .line 1150
    move-result-object v3

    .line 1151
    :goto_47e
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1152
    .line 1153
    .line 1154
    move-result v4

    .line 1155
    if-eqz v4, :cond_497

    .line 1156
    .line 1157
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1158
    .line 1159
    .line 1160
    move-result-object v4

    .line 1161
    check-cast v4, Landroidx/constraintlayout/core/widgets/HelperWidget;

    .line 1162
    .line 1163
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1164
    .line 1165
    .line 1166
    move-result-object v7

    .line 1167
    invoke-virtual {v4, v6, v7, v0}, Landroidx/constraintlayout/core/widgets/HelperWidget;->addDependents(ILandroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;Ljava/util/ArrayList;)V

    .line 1168
    .line 1169
    .line 1170
    invoke-virtual {v7, v0}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->cleanup(Ljava/util/ArrayList;)V

    .line 1171
    .line 1172
    .line 1173
    const/4 v5, 0x0

    .line 1174
    const/4 v6, 0x1

    .line 1175
    goto :goto_47e

    .line 1176
    :cond_497
    sget-object v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;->TOP:Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;

    .line 1177
    .line 1178
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1179
    .line 1180
    .line 1181
    move-result-object v3

    .line 1182
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1183
    .line 1184
    if-eqz v3, :cond_4b9

    .line 1185
    .line 1186
    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1187
    .line 1188
    .line 1189
    move-result-object v3

    .line 1190
    :goto_4a5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1191
    .line 1192
    .line 1193
    move-result v4

    .line 1194
    if-eqz v4, :cond_4b9

    .line 1195
    .line 1196
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1197
    .line 1198
    .line 1199
    move-result-object v4

    .line 1200
    check-cast v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1201
    .line 1202
    iget-object v4, v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1203
    .line 1204
    const/4 v5, 0x0

    .line 1205
    const/4 v6, 0x1

    .line 1206
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1207
    .line 1208
    .line 1209
    goto :goto_4a5

    .line 1210
    :cond_4b9
    sget-object v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;->BASELINE:Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;

    .line 1211
    .line 1212
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v3

    .line 1216
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1217
    .line 1218
    if-eqz v3, :cond_4db

    .line 1219
    .line 1220
    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1221
    .line 1222
    .line 1223
    move-result-object v3

    .line 1224
    :goto_4c7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1225
    .line 1226
    .line 1227
    move-result v4

    .line 1228
    if-eqz v4, :cond_4db

    .line 1229
    .line 1230
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1231
    .line 1232
    .line 1233
    move-result-object v4

    .line 1234
    check-cast v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1235
    .line 1236
    iget-object v4, v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1237
    .line 1238
    const/4 v5, 0x0

    .line 1239
    const/4 v6, 0x1

    .line 1240
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1241
    .line 1242
    .line 1243
    goto :goto_4c7

    .line 1244
    :cond_4db
    sget-object v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;->BOTTOM:Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;

    .line 1245
    .line 1246
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v3

    .line 1250
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1251
    .line 1252
    if-eqz v3, :cond_4fd

    .line 1253
    .line 1254
    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1255
    .line 1256
    .line 1257
    move-result-object v3

    .line 1258
    :goto_4e9
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1259
    .line 1260
    .line 1261
    move-result v4

    .line 1262
    if-eqz v4, :cond_4fd

    .line 1263
    .line 1264
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1265
    .line 1266
    .line 1267
    move-result-object v4

    .line 1268
    check-cast v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1269
    .line 1270
    iget-object v4, v4, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1271
    .line 1272
    const/4 v5, 0x0

    .line 1273
    const/4 v6, 0x1

    .line 1274
    invoke-static {v4, v6, v0, v5}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1275
    .line 1276
    .line 1277
    goto :goto_4e9

    .line 1278
    :cond_4fd
    invoke-virtual {v1, v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getAnchor(Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1279
    .line 1280
    .line 1281
    move-result-object v2

    .line 1282
    iget-object v2, v2, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mDependents:Ljava/util/HashSet;

    .line 1283
    .line 1284
    if-eqz v2, :cond_51d

    .line 1285
    .line 1286
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 1287
    .line 1288
    .line 1289
    move-result-object v2

    .line 1290
    :goto_509
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1291
    .line 1292
    .line 1293
    move-result v3

    .line 1294
    if-eqz v3, :cond_51d

    .line 1295
    .line 1296
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1297
    .line 1298
    .line 1299
    move-result-object v3

    .line 1300
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1301
    .line 1302
    iget-object v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;->mOwner:Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1303
    .line 1304
    const/4 v4, 0x0

    .line 1305
    const/4 v5, 0x1

    .line 1306
    invoke-static {v3, v5, v0, v4}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1307
    .line 1308
    .line 1309
    goto :goto_509

    .line 1310
    :cond_51d
    const/4 v4, 0x0

    .line 1311
    const/4 v5, 0x1

    .line 1312
    if-eqz v15, :cond_535

    .line 1313
    .line 1314
    invoke-virtual {v15}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1315
    .line 1316
    .line 1317
    move-result-object v2

    .line 1318
    :goto_525
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1319
    .line 1320
    .line 1321
    move-result v3

    .line 1322
    if-eqz v3, :cond_535

    .line 1323
    .line 1324
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1325
    .line 1326
    .line 1327
    move-result-object v3

    .line 1328
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1329
    .line 1330
    invoke-static {v3, v5, v0, v4}, Landroidx/constraintlayout/core/widgets/analyzer/Grouping;->findDependents(Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1331
    .line 1332
    .line 1333
    goto :goto_525

    .line 1334
    :cond_535
    const/4 v2, 0x0

    .line 1335
    :goto_536
    if-ge v2, v10, :cond_591

    .line 1336
    .line 1337
    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1338
    .line 1339
    .line 1340
    move-result-object v3

    .line 1341
    check-cast v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1342
    .line 1343
    iget-object v4, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mListDimensionBehaviors:[I

    .line 1344
    .line 1345
    const/4 v6, 0x0

    .line 1346
    aget v7, v4, v6

    .line 1347
    .line 1348
    const/4 v6, 0x3

    .line 1349
    if-ne v7, v6, :cond_54c

    .line 1350
    .line 1351
    aget v4, v4, v5

    .line 1352
    .line 1353
    if-ne v4, v6, :cond_54c

    .line 1354
    .line 1355
    const/4 v4, 0x1

    .line 1356
    goto :goto_54d

    .line 1357
    :cond_54c
    const/4 v4, 0x0

    .line 1358
    :goto_54d
    if-eqz v4, :cond_58d

    .line 1359
    .line 1360
    iget v4, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->horizontalGroup:I

    .line 1361
    .line 1362
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 1363
    .line 1364
    .line 1365
    move-result v5

    .line 1366
    const/4 v7, 0x0

    .line 1367
    :goto_556
    if-ge v7, v5, :cond_566

    .line 1368
    .line 1369
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1370
    .line 1371
    .line 1372
    move-result-object v8

    .line 1373
    check-cast v8, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1374
    .line 1375
    iget v11, v8, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->id:I

    .line 1376
    .line 1377
    if-ne v4, v11, :cond_563

    .line 1378
    .line 1379
    goto :goto_567

    .line 1380
    :cond_563
    add-int/lit8 v7, v7, 0x1

    .line 1381
    .line 1382
    goto :goto_556

    .line 1383
    :cond_566
    const/4 v8, 0x0

    .line 1384
    :goto_567
    iget v3, v3, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->verticalGroup:I

    .line 1385
    .line 1386
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 1387
    .line 1388
    .line 1389
    move-result v4

    .line 1390
    const/4 v5, 0x0

    .line 1391
    :goto_56e
    if-ge v5, v4, :cond_57e

    .line 1392
    .line 1393
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1394
    .line 1395
    .line 1396
    move-result-object v7

    .line 1397
    check-cast v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1398
    .line 1399
    iget v11, v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->id:I

    .line 1400
    .line 1401
    if-ne v3, v11, :cond_57b

    .line 1402
    .line 1403
    goto :goto_57f

    .line 1404
    :cond_57b
    add-int/lit8 v5, v5, 0x1

    .line 1405
    .line 1406
    goto :goto_56e

    .line 1407
    :cond_57e
    const/4 v7, 0x0

    .line 1408
    :goto_57f
    if-eqz v8, :cond_58d

    .line 1409
    .line 1410
    if-eqz v7, :cond_58d

    .line 1411
    .line 1412
    const/4 v3, 0x0

    .line 1413
    invoke-virtual {v8, v3, v7}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->moveTo(ILandroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)V

    .line 1414
    .line 1415
    .line 1416
    const/4 v3, 0x2

    .line 1417
    iput v3, v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->orientation:I

    .line 1418
    .line 1419
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 1420
    .line 1421
    .line 1422
    :cond_58d
    add-int/lit8 v2, v2, 0x1

    .line 1423
    .line 1424
    const/4 v5, 0x1

    .line 1425
    goto :goto_536

    .line 1426
    :cond_591
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 1427
    .line 1428
    .line 1429
    move-result v2

    .line 1430
    const/4 v3, 0x1

    .line 1431
    if-gt v2, v3, :cond_59c

    .line 1432
    .line 1433
    move-object/from16 v8, v28

    .line 1434
    .line 1435
    goto/16 :goto_60b

    .line 1436
    .line 1437
    :cond_59c
    const/4 v2, 0x0

    .line 1438
    aget v4, v22, v2

    .line 1439
    .line 1440
    const/4 v5, 0x2

    .line 1441
    if-ne v4, v5, :cond_5d4

    .line 1442
    .line 1443
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1444
    .line 1445
    .line 1446
    move-result-object v4

    .line 1447
    const/4 v5, 0x0

    .line 1448
    const/4 v6, 0x0

    .line 1449
    :goto_5a8
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1450
    .line 1451
    .line 1452
    move-result v7

    .line 1453
    if-eqz v7, :cond_5c9

    .line 1454
    .line 1455
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v7

    .line 1459
    check-cast v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1460
    .line 1461
    iget v8, v7, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->orientation:I

    .line 1462
    .line 1463
    if-ne v8, v3, :cond_5bb

    .line 1464
    .line 1465
    move-object/from16 v8, v28

    .line 1466
    .line 1467
    goto :goto_5c5

    .line 1468
    :cond_5bb
    move-object/from16 v8, v28

    .line 1469
    .line 1470
    invoke-virtual {v7, v8, v2}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->measureWrap(Landroidx/constraintlayout/core/LinearSystem;I)I

    .line 1471
    .line 1472
    .line 1473
    move-result v9

    .line 1474
    if-le v9, v5, :cond_5c5

    .line 1475
    .line 1476
    move-object v6, v7

    .line 1477
    move v5, v9

    .line 1478
    :cond_5c5
    :goto_5c5
    move-object/from16 v28, v8

    .line 1479
    .line 1480
    const/4 v2, 0x0

    .line 1481
    goto :goto_5a8

    .line 1482
    :cond_5c9
    move-object/from16 v8, v28

    .line 1483
    .line 1484
    if-eqz v6, :cond_5d6

    .line 1485
    .line 1486
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHorizontalDimensionBehaviour$enumunboxing$(I)V

    .line 1487
    .line 1488
    .line 1489
    invoke-virtual {v1, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 1490
    .line 1491
    .line 1492
    goto :goto_5d7

    .line 1493
    :cond_5d4
    move-object/from16 v8, v28

    .line 1494
    .line 1495
    :cond_5d6
    const/4 v6, 0x0

    .line 1496
    :goto_5d7
    aget v2, v22, v3

    .line 1497
    .line 1498
    const/4 v4, 0x2

    .line 1499
    if-ne v2, v4, :cond_605

    .line 1500
    .line 1501
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1502
    .line 1503
    .line 1504
    move-result-object v0

    .line 1505
    const/4 v2, 0x0

    .line 1506
    const/4 v4, 0x0

    .line 1507
    :cond_5e2
    :goto_5e2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1508
    .line 1509
    .line 1510
    move-result v5

    .line 1511
    if-eqz v5, :cond_5fc

    .line 1512
    .line 1513
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1514
    .line 1515
    .line 1516
    move-result-object v5

    .line 1517
    check-cast v5, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;

    .line 1518
    .line 1519
    iget v7, v5, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->orientation:I

    .line 1520
    .line 1521
    if-nez v7, :cond_5f3

    .line 1522
    .line 1523
    goto :goto_5e2

    .line 1524
    :cond_5f3
    invoke-virtual {v5, v8, v3}, Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;->measureWrap(Landroidx/constraintlayout/core/LinearSystem;I)I

    .line 1525
    .line 1526
    .line 1527
    move-result v7

    .line 1528
    if-le v7, v2, :cond_5e2

    .line 1529
    .line 1530
    move-object v4, v5

    .line 1531
    move v2, v7

    .line 1532
    goto :goto_5e2

    .line 1533
    :cond_5fc
    if-eqz v4, :cond_605

    .line 1534
    .line 1535
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setVerticalDimensionBehaviour$enumunboxing$(I)V

    .line 1536
    .line 1537
    .line 1538
    invoke-virtual {v1, v2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 1539
    .line 1540
    .line 1541
    goto :goto_606

    .line 1542
    :cond_605
    const/4 v4, 0x0

    .line 1543
    :goto_606
    if-nez v6, :cond_60d

    .line 1544
    .line 1545
    if-eqz v4, :cond_60b

    .line 1546
    .line 1547
    goto :goto_60d

    .line 1548
    :cond_60b
    :goto_60b
    const/4 v0, 0x0

    .line 1549
    goto :goto_60e

    .line 1550
    :cond_60d
    :goto_60d
    const/4 v0, 0x1

    .line 1551
    :goto_60e
    if-eqz v0, :cond_650

    .line 1552
    .line 1553
    move/from16 v2, v27

    .line 1554
    .line 1555
    const/4 v3, 0x2

    .line 1556
    if-ne v2, v3, :cond_62b

    .line 1557
    .line 1558
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 1559
    .line 1560
    .line 1561
    move-result v0

    .line 1562
    move/from16 v3, v26

    .line 1563
    .line 1564
    if-ge v3, v0, :cond_626

    .line 1565
    .line 1566
    if-lez v3, :cond_626

    .line 1567
    .line 1568
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 1569
    .line 1570
    .line 1571
    const/4 v4, 0x1

    .line 1572
    iput-boolean v4, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mWidthMeasuredTooSmall:Z

    .line 1573
    .line 1574
    goto :goto_62d

    .line 1575
    :cond_626
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 1576
    .line 1577
    .line 1578
    move-result v0

    .line 1579
    goto :goto_62e

    .line 1580
    :cond_62b
    move/from16 v3, v26

    .line 1581
    .line 1582
    :goto_62d
    move v0, v3

    .line 1583
    :goto_62e
    move/from16 v4, v24

    .line 1584
    .line 1585
    const/4 v3, 0x2

    .line 1586
    if-ne v4, v3, :cond_649

    .line 1587
    .line 1588
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 1589
    .line 1590
    .line 1591
    move-result v3

    .line 1592
    move/from16 v5, v20

    .line 1593
    .line 1594
    if-ge v5, v3, :cond_644

    .line 1595
    .line 1596
    if-lez v5, :cond_644

    .line 1597
    .line 1598
    invoke-virtual {v1, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 1599
    .line 1600
    .line 1601
    const/4 v3, 0x1

    .line 1602
    iput-boolean v3, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHeightMeasuredTooSmall:Z

    .line 1603
    .line 1604
    goto :goto_64b

    .line 1605
    :cond_644
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 1606
    .line 1607
    .line 1608
    move-result v3

    .line 1609
    goto :goto_64c

    .line 1610
    :cond_649
    move/from16 v5, v20

    .line 1611
    .line 1612
    :goto_64b
    move v3, v5

    .line 1613
    :goto_64c
    move v5, v3

    .line 1614
    move v3, v0

    .line 1615
    const/4 v0, 0x1

    .line 1616
    goto :goto_667

    .line 1617
    :cond_650
    move/from16 v5, v20

    .line 1618
    .line 1619
    move/from16 v4, v24

    .line 1620
    .line 1621
    move/from16 v3, v26

    .line 1622
    .line 1623
    move/from16 v2, v27

    .line 1624
    .line 1625
    goto :goto_666

    .line 1626
    :cond_659
    move/from16 v25, v3

    .line 1627
    .line 1628
    move v4, v7

    .line 1629
    move-object/from16 v23, v12

    .line 1630
    .line 1631
    move/from16 v5, v20

    .line 1632
    .line 1633
    move v3, v0

    .line 1634
    move/from16 v29, v8

    .line 1635
    .line 1636
    move-object v8, v2

    .line 1637
    move/from16 v2, v29

    .line 1638
    .line 1639
    :goto_666
    const/4 v0, 0x0

    .line 1640
    :goto_667
    const/16 v6, 0x40

    .line 1641
    .line 1642
    invoke-virtual {v1, v6}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->optimizeFor(I)Z

    .line 1643
    .line 1644
    .line 1645
    move-result v7

    .line 1646
    if-nez v7, :cond_67a

    .line 1647
    .line 1648
    const/16 v7, 0x80

    .line 1649
    .line 1650
    invoke-virtual {v1, v7}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->optimizeFor(I)Z

    .line 1651
    .line 1652
    .line 1653
    move-result v7

    .line 1654
    if-eqz v7, :cond_678

    .line 1655
    .line 1656
    goto :goto_67a

    .line 1657
    :cond_678
    const/4 v7, 0x0

    .line 1658
    goto :goto_67b

    .line 1659
    :cond_67a
    :goto_67a
    const/4 v7, 0x1

    .line 1660
    :goto_67b
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1661
    .line 1662
    .line 1663
    const/4 v9, 0x0

    .line 1664
    iput-boolean v9, v8, Landroidx/constraintlayout/core/LinearSystem;->newgraphOptimizer:Z

    .line 1665
    .line 1666
    iget v10, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mOptimizationLevel:I

    .line 1667
    .line 1668
    if-eqz v10, :cond_68b

    .line 1669
    .line 1670
    if-eqz v7, :cond_68b

    .line 1671
    .line 1672
    const/4 v7, 0x1

    .line 1673
    iput-boolean v7, v8, Landroidx/constraintlayout/core/LinearSystem;->newgraphOptimizer:Z

    .line 1674
    .line 1675
    goto :goto_68c

    .line 1676
    :cond_68b
    const/4 v7, 0x1

    .line 1677
    :goto_68c
    iget-object v10, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 1678
    .line 1679
    aget v11, v22, v9

    .line 1680
    .line 1681
    const/4 v12, 0x2

    .line 1682
    if-eq v11, v12, :cond_69a

    .line 1683
    .line 1684
    aget v11, v22, v7

    .line 1685
    .line 1686
    if-ne v11, v12, :cond_698

    .line 1687
    .line 1688
    goto :goto_69a

    .line 1689
    :cond_698
    const/4 v7, 0x0

    .line 1690
    goto :goto_69b

    .line 1691
    :cond_69a
    :goto_69a
    const/4 v7, 0x1

    .line 1692
    :goto_69b
    iput v9, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 1693
    .line 1694
    iput v9, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 1695
    .line 1696
    move/from16 v11, v25

    .line 1697
    .line 1698
    const/4 v9, 0x0

    .line 1699
    :goto_6a2
    if-ge v9, v11, :cond_6b8

    .line 1700
    .line 1701
    iget-object v12, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 1702
    .line 1703
    invoke-virtual {v12, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1704
    .line 1705
    .line 1706
    move-result-object v12

    .line 1707
    check-cast v12, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1708
    .line 1709
    instance-of v13, v12, Landroidx/constraintlayout/core/widgets/WidgetContainer;

    .line 1710
    .line 1711
    if-eqz v13, :cond_6b5

    .line 1712
    .line 1713
    check-cast v12, Landroidx/constraintlayout/core/widgets/WidgetContainer;

    .line 1714
    .line 1715
    invoke-virtual {v12}, Landroidx/constraintlayout/core/widgets/WidgetContainer;->layout()V

    .line 1716
    .line 1717
    .line 1718
    :cond_6b5
    add-int/lit8 v9, v9, 0x1

    .line 1719
    .line 1720
    goto :goto_6a2

    .line 1721
    :cond_6b8
    invoke-virtual {v1, v6}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->optimizeFor(I)Z

    .line 1722
    .line 1723
    .line 1724
    move-result v9

    .line 1725
    move v12, v0

    .line 1726
    const/4 v0, 0x0

    .line 1727
    const/4 v13, 0x1

    .line 1728
    :goto_6bf
    if-eqz v13, :cond_8f0

    .line 1729
    .line 1730
    const/4 v14, 0x1

    .line 1731
    add-int/lit8 v15, v0, 0x1

    .line 1732
    .line 1733
    :try_start_6c4
    invoke-virtual {v8}, Landroidx/constraintlayout/core/LinearSystem;->reset()V

    .line 1734
    .line 1735
    .line 1736
    const/4 v14, 0x0

    .line 1737
    iput v14, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHorizontalChainsSize:I

    .line 1738
    .line 1739
    iput v14, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mVerticalChainsSize:I

    .line 1740
    .line 1741
    invoke-virtual {v1, v8}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->createObjectVariables(Landroidx/constraintlayout/core/LinearSystem;)V

    .line 1742
    .line 1743
    .line 1744
    const/4 v0, 0x0

    .line 1745
    :goto_6d0
    if-ge v0, v11, :cond_6e0

    .line 1746
    .line 1747
    iget-object v14, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 1748
    .line 1749
    invoke-virtual {v14, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1750
    .line 1751
    .line 1752
    move-result-object v14

    .line 1753
    check-cast v14, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 1754
    .line 1755
    invoke-virtual {v14, v8}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->createObjectVariables(Landroidx/constraintlayout/core/LinearSystem;)V

    .line 1756
    .line 1757
    .line 1758
    add-int/lit8 v0, v0, 0x1

    .line 1759
    .line 1760
    goto :goto_6d0

    .line 1761
    :cond_6e0
    invoke-virtual {v1, v8}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->addChildrenToSolver(Landroidx/constraintlayout/core/LinearSystem;)V
    :try_end_6e3
    .catch Ljava/lang/Exception; {:try_start_6c4 .. :try_end_6e3} :catch_790

    .line 1762
    .line 1763
    .line 1764
    :try_start_6e3
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMin:Ljava/lang/ref/WeakReference;
    :try_end_6e5
    .catch Ljava/lang/Exception; {:try_start_6e3 .. :try_end_6e5} :catch_784

    .line 1765
    .line 1766
    const/4 v13, 0x5

    .line 1767
    if-eqz v0, :cond_710

    .line 1768
    .line 1769
    :try_start_6e8
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1770
    .line 1771
    .line 1772
    move-result-object v0

    .line 1773
    if-eqz v0, :cond_710

    .line 1774
    .line 1775
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMin:Ljava/lang/ref/WeakReference;

    .line 1776
    .line 1777
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1778
    .line 1779
    .line 1780
    move-result-object v0

    .line 1781
    check-cast v0, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    :try_end_6f6
    .catch Ljava/lang/Exception; {:try_start_6e8 .. :try_end_6f6} :catch_70a

    .line 1782
    .line 1783
    move-object/from16 v14, v23

    .line 1784
    .line 1785
    :try_start_6f8
    invoke-virtual {v8, v14}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1786
    .line 1787
    .line 1788
    move-result-object v6

    .line 1789
    invoke-virtual {v8, v0}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1790
    .line 1791
    .line 1792
    move-result-object v0
    :try_end_700
    .catch Ljava/lang/Exception; {:try_start_6f8 .. :try_end_700} :catch_70c

    .line 1793
    move-object/from16 v23, v14

    .line 1794
    .line 1795
    const/4 v14, 0x0

    .line 1796
    :try_start_703
    invoke-virtual {v8, v0, v6, v14, v13}, Landroidx/constraintlayout/core/LinearSystem;->addGreaterThan(Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V

    .line 1797
    .line 1798
    .line 1799
    const/4 v6, 0x0

    .line 1800
    iput-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMin:Ljava/lang/ref/WeakReference;
    :try_end_709
    .catch Ljava/lang/Exception; {:try_start_703 .. :try_end_709} :catch_70a

    .line 1801
    .line 1802
    goto :goto_710

    .line 1803
    :catch_70a
    move-exception v0

    .line 1804
    goto :goto_734

    .line 1805
    :catch_70c
    move-exception v0

    .line 1806
    move-object/from16 v23, v14

    .line 1807
    .line 1808
    goto :goto_734

    .line 1809
    :cond_710
    :goto_710
    :try_start_710
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMax:Ljava/lang/ref/WeakReference;
    :try_end_712
    .catch Ljava/lang/Exception; {:try_start_710 .. :try_end_712} :catch_784

    .line 1810
    .line 1811
    if-eqz v0, :cond_736

    .line 1812
    .line 1813
    :try_start_714
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1814
    .line 1815
    .line 1816
    move-result-object v0

    .line 1817
    if-eqz v0, :cond_736

    .line 1818
    .line 1819
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMax:Ljava/lang/ref/WeakReference;

    .line 1820
    .line 1821
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1822
    .line 1823
    .line 1824
    move-result-object v0

    .line 1825
    check-cast v0, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1826
    .line 1827
    iget-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mBottom:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1828
    .line 1829
    invoke-virtual {v8, v6}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1830
    .line 1831
    .line 1832
    move-result-object v6

    .line 1833
    invoke-virtual {v8, v0}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1834
    .line 1835
    .line 1836
    move-result-object v0

    .line 1837
    const/4 v14, 0x0

    .line 1838
    invoke-virtual {v8, v6, v0, v14, v13}, Landroidx/constraintlayout/core/LinearSystem;->addGreaterThan(Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V

    .line 1839
    .line 1840
    .line 1841
    const/4 v6, 0x0

    .line 1842
    iput-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->verticalWrapMax:Ljava/lang/ref/WeakReference;
    :try_end_733
    .catch Ljava/lang/Exception; {:try_start_714 .. :try_end_733} :catch_70a

    .line 1843
    .line 1844
    goto :goto_736

    .line 1845
    :goto_734
    const/4 v6, 0x0

    .line 1846
    goto :goto_78e

    .line 1847
    :cond_736
    :goto_736
    :try_start_736
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMin:Ljava/lang/ref/WeakReference;

    .line 1848
    .line 1849
    if-eqz v0, :cond_760

    .line 1850
    .line 1851
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1852
    .line 1853
    .line 1854
    move-result-object v0

    .line 1855
    if-eqz v0, :cond_760

    .line 1856
    .line 1857
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMin:Ljava/lang/ref/WeakReference;

    .line 1858
    .line 1859
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1860
    .line 1861
    .line 1862
    move-result-object v0

    .line 1863
    check-cast v0, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    :try_end_748
    .catch Ljava/lang/Exception; {:try_start_736 .. :try_end_748} :catch_784

    .line 1864
    .line 1865
    move-object/from16 v6, v21

    .line 1866
    .line 1867
    :try_start_74a
    invoke-virtual {v8, v6}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1868
    .line 1869
    .line 1870
    move-result-object v14

    .line 1871
    invoke-virtual {v8, v0}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1872
    .line 1873
    .line 1874
    move-result-object v0
    :try_end_752
    .catch Ljava/lang/Exception; {:try_start_74a .. :try_end_752} :catch_75c

    .line 1875
    move-object/from16 v21, v6

    .line 1876
    .line 1877
    const/4 v6, 0x0

    .line 1878
    :try_start_755
    invoke-virtual {v8, v0, v14, v6, v13}, Landroidx/constraintlayout/core/LinearSystem;->addGreaterThan(Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    :try_end_758
    .catch Ljava/lang/Exception; {:try_start_755 .. :try_end_758} :catch_784

    .line 1879
    .line 1880
    .line 1881
    const/4 v6, 0x0

    .line 1882
    :try_start_759
    iput-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMin:Ljava/lang/ref/WeakReference;
    :try_end_75b
    .catch Ljava/lang/Exception; {:try_start_759 .. :try_end_75b} :catch_78d

    .line 1883
    .line 1884
    goto :goto_760

    .line 1885
    :catch_75c
    move-exception v0

    .line 1886
    move-object/from16 v21, v6

    .line 1887
    .line 1888
    goto :goto_734

    .line 1889
    :cond_760
    :goto_760
    :try_start_760
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMax:Ljava/lang/ref/WeakReference;

    .line 1890
    .line 1891
    if-eqz v0, :cond_786

    .line 1892
    .line 1893
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1894
    .line 1895
    .line 1896
    move-result-object v0

    .line 1897
    if-eqz v0, :cond_786

    .line 1898
    .line 1899
    iget-object v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMax:Ljava/lang/ref/WeakReference;

    .line 1900
    .line 1901
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v0

    .line 1905
    check-cast v0, Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1906
    .line 1907
    iget-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mRight:Landroidx/constraintlayout/core/widgets/ConstraintAnchor;

    .line 1908
    .line 1909
    invoke-virtual {v8, v6}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1910
    .line 1911
    .line 1912
    move-result-object v6

    .line 1913
    invoke-virtual {v8, v0}, Landroidx/constraintlayout/core/LinearSystem;->createObjectVariable(Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;

    .line 1914
    .line 1915
    .line 1916
    move-result-object v0

    .line 1917
    const/4 v14, 0x0

    .line 1918
    invoke-virtual {v8, v6, v0, v14, v13}, Landroidx/constraintlayout/core/LinearSystem;->addGreaterThan(Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    :try_end_780
    .catch Ljava/lang/Exception; {:try_start_760 .. :try_end_780} :catch_784

    .line 1919
    .line 1920
    .line 1921
    const/4 v6, 0x0

    .line 1922
    :try_start_781
    iput-object v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->horizontalWrapMax:Ljava/lang/ref/WeakReference;

    .line 1923
    .line 1924
    goto :goto_787

    .line 1925
    :catch_784
    move-exception v0

    .line 1926
    goto :goto_734

    .line 1927
    :cond_786
    const/4 v6, 0x0

    .line 1928
    :goto_787
    invoke-virtual {v8}, Landroidx/constraintlayout/core/LinearSystem;->minimize()V
    :try_end_78a
    .catch Ljava/lang/Exception; {:try_start_781 .. :try_end_78a} :catch_78d

    .line 1929
    .line 1930
    .line 1931
    const/16 v20, 0x1

    .line 1932
    .line 1933
    goto :goto_7aa

    .line 1934
    :catch_78d
    move-exception v0

    .line 1935
    :goto_78e
    const/4 v13, 0x1

    .line 1936
    goto :goto_792

    .line 1937
    :catch_790
    move-exception v0

    .line 1938
    const/4 v6, 0x0

    .line 1939
    :goto_792
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 1940
    .line 1941
    .line 1942
    sget-object v14, Ljava/lang/System;->out:Ljava/io/PrintStream;

    .line 1943
    .line 1944
    new-instance v6, Ljava/lang/StringBuilder;

    .line 1945
    .line 1946
    move/from16 v20, v13

    .line 1947
    .line 1948
    const-string v13, "EXCEPTION : "

    .line 1949
    .line 1950
    invoke-direct {v6, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1951
    .line 1952
    .line 1953
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1954
    .line 1955
    .line 1956
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1957
    .line 1958
    .line 1959
    move-result-object v0

    .line 1960
    invoke-virtual {v14, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 1961
    .line 1962
    .line 1963
    :goto_7aa
    sget-object v0, Landroidx/constraintlayout/core/widgets/Optimizer;->flags:[Z

    .line 1964
    .line 1965
    if-eqz v20, :cond_7f5

    .line 1966
    .line 1967
    const/4 v6, 0x2

    .line 1968
    const/4 v13, 0x0

    .line 1969
    aput-boolean v13, v0, v6

    .line 1970
    .line 1971
    const/16 v6, 0x40

    .line 1972
    .line 1973
    invoke-virtual {v1, v6}, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->optimizeFor(I)Z

    .line 1974
    .line 1975
    .line 1976
    move-result v13

    .line 1977
    invoke-virtual {v1, v8, v13}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->updateFromSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 1978
    .line 1979
    .line 1980
    iget-object v14, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 1981
    .line 1982
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    .line 1983
    .line 1984
    .line 1985
    move-result v14

    .line 1986
    const/4 v6, 0x0

    .line 1987
    const/16 v20, 0x0

    .line 1988
    .line 1989
    :goto_7c4
    if-ge v6, v14, :cond_7f1

    .line 1990
    .line 1991
    move/from16 v24, v14

    .line 1992
    .line 1993
    iget-object v14, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 1994
    .line 1995
    invoke-virtual {v14, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1996
    .line 1997
    .line 1998
    move-result-object v14

    .line 1999
    check-cast v14, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 2000
    .line 2001
    invoke-virtual {v14, v8, v13}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->updateFromSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 2002
    .line 2003
    .line 2004
    move/from16 v25, v13

    .line 2005
    .line 2006
    iget v13, v14, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mWidthOverride:I

    .line 2007
    .line 2008
    move/from16 v26, v12

    .line 2009
    .line 2010
    const/4 v12, -0x1

    .line 2011
    if-ne v13, v12, :cond_7e3

    .line 2012
    .line 2013
    iget v13, v14, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mHeightOverride:I

    .line 2014
    .line 2015
    if-eq v13, v12, :cond_7e1

    .line 2016
    .line 2017
    goto :goto_7e3

    .line 2018
    :cond_7e1
    const/4 v13, 0x0

    .line 2019
    goto :goto_7e4

    .line 2020
    :cond_7e3
    :goto_7e3
    const/4 v13, 0x1

    .line 2021
    :goto_7e4
    if-eqz v13, :cond_7e8

    .line 2022
    .line 2023
    const/16 v20, 0x1

    .line 2024
    .line 2025
    :cond_7e8
    add-int/lit8 v6, v6, 0x1

    .line 2026
    .line 2027
    move/from16 v14, v24

    .line 2028
    .line 2029
    move/from16 v13, v25

    .line 2030
    .line 2031
    move/from16 v12, v26

    .line 2032
    .line 2033
    goto :goto_7c4

    .line 2034
    :cond_7f1
    move/from16 v26, v12

    .line 2035
    .line 2036
    const/4 v12, -0x1

    .line 2037
    goto :goto_80e

    .line 2038
    :cond_7f5
    move/from16 v26, v12

    .line 2039
    .line 2040
    const/4 v12, -0x1

    .line 2041
    invoke-virtual {v1, v8, v9}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->updateFromSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 2042
    .line 2043
    .line 2044
    const/4 v6, 0x0

    .line 2045
    :goto_7fc
    if-ge v6, v11, :cond_80c

    .line 2046
    .line 2047
    iget-object v13, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 2048
    .line 2049
    invoke-virtual {v13, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 2050
    .line 2051
    .line 2052
    move-result-object v13

    .line 2053
    check-cast v13, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 2054
    .line 2055
    invoke-virtual {v13, v8, v9}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->updateFromSolver(Landroidx/constraintlayout/core/LinearSystem;Z)V

    .line 2056
    .line 2057
    .line 2058
    add-int/lit8 v6, v6, 0x1

    .line 2059
    .line 2060
    goto :goto_7fc

    .line 2061
    :cond_80c
    const/16 v20, 0x0

    .line 2062
    .line 2063
    :goto_80e
    const/16 v6, 0x8

    .line 2064
    .line 2065
    if-eqz v7, :cond_874

    .line 2066
    .line 2067
    if-ge v15, v6, :cond_874

    .line 2068
    .line 2069
    const/4 v13, 0x2

    .line 2070
    aget-boolean v0, v0, v13

    .line 2071
    .line 2072
    if-eqz v0, :cond_874

    .line 2073
    .line 2074
    const/4 v0, 0x0

    .line 2075
    const/4 v13, 0x0

    .line 2076
    const/4 v14, 0x0

    .line 2077
    :goto_81c
    if-ge v0, v11, :cond_843

    .line 2078
    .line 2079
    iget-object v12, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 2080
    .line 2081
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 2082
    .line 2083
    .line 2084
    move-result-object v12

    .line 2085
    check-cast v12, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 2086
    .line 2087
    iget v6, v12, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mX:I

    .line 2088
    .line 2089
    invoke-virtual {v12}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 2090
    .line 2091
    .line 2092
    move-result v25

    .line 2093
    add-int v6, v25, v6

    .line 2094
    .line 2095
    invoke-static {v13, v6}, Ljava/lang/Math;->max(II)I

    .line 2096
    .line 2097
    .line 2098
    move-result v13

    .line 2099
    iget v6, v12, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mY:I

    .line 2100
    .line 2101
    invoke-virtual {v12}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 2102
    .line 2103
    .line 2104
    move-result v12

    .line 2105
    add-int/2addr v12, v6

    .line 2106
    invoke-static {v14, v12}, Ljava/lang/Math;->max(II)I

    .line 2107
    .line 2108
    .line 2109
    move-result v14

    .line 2110
    add-int/lit8 v0, v0, 0x1

    .line 2111
    .line 2112
    const/16 v6, 0x8

    .line 2113
    .line 2114
    const/4 v12, -0x1

    .line 2115
    goto :goto_81c

    .line 2116
    :cond_843
    iget v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMinWidth:I

    .line 2117
    .line 2118
    invoke-static {v0, v13}, Ljava/lang/Math;->max(II)I

    .line 2119
    .line 2120
    .line 2121
    move-result v0

    .line 2122
    iget v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMinHeight:I

    .line 2123
    .line 2124
    invoke-static {v6, v14}, Ljava/lang/Math;->max(II)I

    .line 2125
    .line 2126
    .line 2127
    move-result v6

    .line 2128
    const/4 v12, 0x2

    .line 2129
    if-ne v2, v12, :cond_862

    .line 2130
    .line 2131
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 2132
    .line 2133
    .line 2134
    move-result v13

    .line 2135
    if-ge v13, v0, :cond_862

    .line 2136
    .line 2137
    invoke-virtual {v1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 2138
    .line 2139
    .line 2140
    const/4 v13, 0x0

    .line 2141
    aput v12, v22, v13

    .line 2142
    .line 2143
    const/16 v20, 0x1

    .line 2144
    .line 2145
    const/16 v26, 0x1

    .line 2146
    .line 2147
    :cond_862
    if-ne v4, v12, :cond_874

    .line 2148
    .line 2149
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 2150
    .line 2151
    .line 2152
    move-result v0

    .line 2153
    if-ge v0, v6, :cond_874

    .line 2154
    .line 2155
    invoke-virtual {v1, v6}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 2156
    .line 2157
    .line 2158
    const/4 v6, 0x1

    .line 2159
    aput v12, v22, v6

    .line 2160
    .line 2161
    const/16 v20, 0x1

    .line 2162
    .line 2163
    const/16 v26, 0x1

    .line 2164
    .line 2165
    :cond_874
    iget v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMinWidth:I

    .line 2166
    .line 2167
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 2168
    .line 2169
    .line 2170
    move-result v6

    .line 2171
    invoke-static {v0, v6}, Ljava/lang/Math;->max(II)I

    .line 2172
    .line 2173
    .line 2174
    move-result v0

    .line 2175
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 2176
    .line 2177
    .line 2178
    move-result v6

    .line 2179
    if-le v0, v6, :cond_890

    .line 2180
    .line 2181
    invoke-virtual {v1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 2182
    .line 2183
    .line 2184
    const/4 v6, 0x1

    .line 2185
    const/4 v12, 0x0

    .line 2186
    aput v6, v22, v12

    .line 2187
    .line 2188
    const/16 v17, 0x1

    .line 2189
    .line 2190
    const/16 v20, 0x1

    .line 2191
    .line 2192
    goto :goto_893

    .line 2193
    :cond_890
    const/4 v6, 0x1

    .line 2194
    move/from16 v17, v26

    .line 2195
    .line 2196
    :goto_893
    iget v0, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->mMinHeight:I

    .line 2197
    .line 2198
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 2199
    .line 2200
    .line 2201
    move-result v12

    .line 2202
    invoke-static {v0, v12}, Ljava/lang/Math;->max(II)I

    .line 2203
    .line 2204
    .line 2205
    move-result v0

    .line 2206
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 2207
    .line 2208
    .line 2209
    move-result v12

    .line 2210
    if-le v0, v12, :cond_8ac

    .line 2211
    .line 2212
    invoke-virtual {v1, v0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 2213
    .line 2214
    .line 2215
    aput v6, v22, v6

    .line 2216
    .line 2217
    const/4 v0, 0x1

    .line 2218
    const/16 v20, 0x1

    .line 2219
    .line 2220
    goto :goto_8ae

    .line 2221
    :cond_8ac
    move/from16 v0, v17

    .line 2222
    .line 2223
    :goto_8ae
    if-nez v0, :cond_8e1

    .line 2224
    .line 2225
    const/4 v12, 0x0

    .line 2226
    aget v13, v22, v12

    .line 2227
    .line 2228
    const/4 v14, 0x2

    .line 2229
    if-ne v13, v14, :cond_8c8

    .line 2230
    .line 2231
    if-lez v3, :cond_8c8

    .line 2232
    .line 2233
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getWidth()I

    .line 2234
    .line 2235
    .line 2236
    move-result v13

    .line 2237
    if-le v13, v3, :cond_8c8

    .line 2238
    .line 2239
    iput-boolean v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mWidthMeasuredTooSmall:Z

    .line 2240
    .line 2241
    aput v6, v22, v12

    .line 2242
    .line 2243
    invoke-virtual {v1, v3}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setWidth(I)V

    .line 2244
    .line 2245
    .line 2246
    const/4 v0, 0x1

    .line 2247
    const/16 v20, 0x1

    .line 2248
    .line 2249
    :cond_8c8
    aget v12, v22, v6

    .line 2250
    .line 2251
    const/4 v13, 0x2

    .line 2252
    if-ne v12, v13, :cond_8e2

    .line 2253
    .line 2254
    if-lez v5, :cond_8e2

    .line 2255
    .line 2256
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->getHeight()I

    .line 2257
    .line 2258
    .line 2259
    move-result v12

    .line 2260
    if-le v12, v5, :cond_8e2

    .line 2261
    .line 2262
    iput-boolean v6, v1, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mHeightMeasuredTooSmall:Z

    .line 2263
    .line 2264
    aput v6, v22, v6

    .line 2265
    .line 2266
    invoke-virtual {v1, v5}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->setHeight(I)V

    .line 2267
    .line 2268
    .line 2269
    const/16 v0, 0x8

    .line 2270
    .line 2271
    const/4 v6, 0x1

    .line 2272
    const/4 v12, 0x1

    .line 2273
    goto :goto_8e7

    .line 2274
    :cond_8e1
    const/4 v13, 0x2

    .line 2275
    :cond_8e2
    move v12, v0

    .line 2276
    move/from16 v6, v20

    .line 2277
    .line 2278
    const/16 v0, 0x8

    .line 2279
    .line 2280
    :goto_8e7
    if-le v15, v0, :cond_8ea

    .line 2281
    .line 2282
    const/4 v6, 0x0

    .line 2283
    :cond_8ea
    move v13, v6

    .line 2284
    move v0, v15

    .line 2285
    const/16 v6, 0x40

    .line 2286
    .line 2287
    goto/16 :goto_6bf

    .line 2288
    .line 2289
    :cond_8f0
    move/from16 v26, v12

    .line 2290
    .line 2291
    iput-object v10, v1, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 2292
    .line 2293
    if-eqz v26, :cond_8fc

    .line 2294
    .line 2295
    const/4 v3, 0x0

    .line 2296
    aput v2, v22, v3

    .line 2297
    .line 2298
    const/4 v2, 0x1

    .line 2299
    aput v4, v22, v2

    .line 2300
    .line 2301
    :cond_8fc
    iget-object v0, v8, Landroidx/constraintlayout/core/LinearSystem;->mCache:Landroidx/constraintlayout/core/Cache;

    .line 2302
    .line 2303
    invoke-virtual {v1, v0}, Landroidx/constraintlayout/core/widgets/WidgetContainer;->resetSolverVariables(Landroidx/constraintlayout/core/Cache;)V

    .line 2304
    .line 2305
    .line 2306
    return-void
.end method

.method public final optimizeFor(I)Z
    .registers 3

    .line 1
    iget v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mOptimizationLevel:I

    .line 2
    .line 3
    and-int/2addr v0, p1

    .line 4
    if-ne v0, p1, :cond_7

    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    goto :goto_8

    .line 8
    :cond_7
    const/4 p1, 0x0

    .line 9
    :goto_8
    return p1
.end method

.method public final reset()V
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mSystem:Landroidx/constraintlayout/core/LinearSystem;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/constraintlayout/core/LinearSystem;->reset()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mPaddingLeft:I

    .line 8
    .line 9
    iput v0, p0, Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;->mPaddingTop:I

    .line 10
    .line 11
    invoke-super {p0}, Landroidx/constraintlayout/core/widgets/WidgetContainer;->reset()V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final updateFromRuns(ZZ)V
    .registers 6

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->updateFromRuns(ZZ)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/4 v1, 0x0

    .line 11
    :goto_a
    if-ge v1, v0, :cond_1a

    .line 12
    .line 13
    iget-object v2, p0, Landroidx/constraintlayout/core/widgets/WidgetContainer;->mChildren:Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    check-cast v2, Landroidx/constraintlayout/core/widgets/ConstraintWidget;

    .line 20
    .line 21
    invoke-virtual {v2, p1, p2}, Landroidx/constraintlayout/core/widgets/ConstraintWidget;->updateFromRuns(ZZ)V

    .line 22
    .line 23
    .line 24
    add-int/lit8 v1, v1, 0x1

    .line 25
    .line 26
    goto :goto_a

    .line 27
    :cond_1a
    return-void
.end method
