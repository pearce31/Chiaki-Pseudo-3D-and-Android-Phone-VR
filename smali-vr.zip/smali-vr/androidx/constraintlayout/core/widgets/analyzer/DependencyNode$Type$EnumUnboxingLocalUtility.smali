.class public final synthetic Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode$Type$EnumUnboxingLocalUtility;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static synthetic stringValueOf(I)Ljava/lang/String;
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, v0, :cond_6

    .line 3
    .line 4
    const-string p0, "UNKNOWN"

    .line 5
    .line 6
    return-object p0

    .line 7
    :cond_6
    const/4 v0, 0x2

    .line 8
    if-ne p0, v0, :cond_c

    .line 9
    .line 10
    const-string p0, "HORIZONTAL_DIMENSION"

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_c
    const/4 v0, 0x3

    .line 14
    if-ne p0, v0, :cond_12

    .line 15
    .line 16
    const-string p0, "VERTICAL_DIMENSION"

    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_12
    const/4 v0, 0x4

    .line 20
    if-ne p0, v0, :cond_18

    .line 21
    .line 22
    const-string p0, "LEFT"

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_18
    const/4 v0, 0x5

    .line 26
    if-ne p0, v0, :cond_1e

    .line 27
    .line 28
    const-string p0, "RIGHT"

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1e
    const/4 v0, 0x6

    .line 32
    if-ne p0, v0, :cond_24

    .line 33
    .line 34
    const-string p0, "TOP"

    .line 35
    .line 36
    return-object p0

    .line 37
    :cond_24
    const/4 v0, 0x7

    .line 38
    if-ne p0, v0, :cond_2a

    .line 39
    .line 40
    const-string p0, "BOTTOM"

    .line 41
    .line 42
    return-object p0

    .line 43
    :cond_2a
    const/16 v0, 0x8

    .line 44
    .line 45
    if-ne p0, v0, :cond_31

    .line 46
    .line 47
    const-string p0, "BASELINE"

    .line 48
    .line 49
    return-object p0

    .line 50
    :cond_31
    const-string p0, "null"

    .line 51
    .line 52
    return-object p0
.end method
